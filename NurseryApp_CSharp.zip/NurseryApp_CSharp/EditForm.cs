using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using MySqlConnector;

namespace Nursery;

/// <summary>Универсальная форма добавления и изменения записи по списку полей.</summary>
public class EditForm : Form
{
    private readonly Field[] fields;
    private readonly Action<Dictionary<string, object>> save;
    private readonly Dictionary<string, Control> inputs = new Dictionary<string, Control>();
    private readonly Dictionary<string, TextBox> fileBoxes = new Dictionary<string, TextBox>();

    public EditForm(string title, Field[] fields, DataRow row, Action<Dictionary<string, object>> save)
    {
        this.fields = fields;
        this.save = save;

        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        Text = title;
        Font = Theme.F(10f);
        BackColor = Color.White;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;

        int y = 16;
        foreach (Field f in fields)
        {
            Label lab = new Label();
            lab.Text = f.Label + (f.Required ? " *" : "");
            lab.Left = 16;
            lab.Top = y + 4;
            lab.Width = 200;
            lab.ForeColor = Theme.Green;
            Controls.Add(lab);

            Control ctl = BuildInput(f, row);
            ctl.Left = 222;
            ctl.Top = y;
            ctl.Width = 320;
            Controls.Add(ctl);
            inputs[f.Col] = ctl;
            y += 38;
        }

        Button ok = new Button();
        ok.Text = "Сохранить";
        ok.Left = 222;
        ok.Top = y + 8;
        ok.Width = 150;
        Theme.StyleButton(ok);
        ok.Click += (s, e) => OnOk();
        Controls.Add(ok);

        Button cancel = new Button();
        cancel.Text = "Отмена";
        cancel.Left = 382;
        cancel.Top = y + 8;
        cancel.Width = 160;
        Theme.StyleButton(cancel, true);
        cancel.DialogResult = DialogResult.Cancel;
        Controls.Add(cancel);

        AcceptButton = ok;
        CancelButton = cancel;
        ClientSize = new Size(560, y + 62);
    }

    private static string FormatValue(object v)
    {
        if (v is decimal) return ((decimal)v).ToString("0.##", CultureInfo.InvariantCulture);
        return Convert.ToString(v, CultureInfo.InvariantCulture);
    }

    private Control BuildInput(Field f, DataRow row)
    {
        object v = null;
        if (row != null && row.Table.Columns.Contains(f.Col))
        {
            v = row[f.Col];
            if (v is DBNull) v = null;
        }

        if (f.Kind == Kind.Date)
        {
            DateTimePicker dtp = new DateTimePicker();
            dtp.Format = DateTimePickerFormat.Short;
            dtp.ShowCheckBox = !f.Required;
            if (v != null)
            {
                dtp.Value = Convert.ToDateTime(v);
                if (!f.Required) dtp.Checked = true;
            }
            else if (!f.Required)
            {
                dtp.Checked = false;
            }
            return dtp;
        }

        if (f.Kind == Kind.Combo)
        {
            ComboBox cb = new ComboBox();
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
            cb.Items.AddRange(f.Items);
            if (v != null) cb.SelectedItem = Convert.ToString(v);
            if (cb.SelectedIndex < 0 && cb.Items.Count > 0) cb.SelectedIndex = 0;
            return cb;
        }

        if (f.Kind == Kind.Lookup)
        {
            ComboBox cb = new ComboBox();
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
            if (!f.Required) cb.Items.Add(new ComboItem { Id = -1, Text = "— не выбрано —" });
            List<ComboItem> list = Db.Lookup(f.Sql);
            cb.Items.AddRange(list.ToArray());
            if (v != null)
            {
                int id = Convert.ToInt32(v);
                foreach (object o in cb.Items)
                {
                    ComboItem it = (ComboItem)o;
                    if (it.Id == id) cb.SelectedItem = it;
                }
            }
            else if (!f.Required)
            {
                cb.SelectedIndex = 0;
            }
            return cb;
        }

        if (f.Kind == Kind.File)
        {
            Panel p = new Panel();
            p.Height = 28;
            TextBox tb = new TextBox();
            tb.Left = 0;
            tb.Top = 0;
            tb.Width = 220;
            if (v != null) tb.Text = Convert.ToString(v);
            Button br = new Button();
            br.Text = "Обзор...";
            br.Left = 228;
            br.Top = 0;
            br.Width = 92;
            br.Height = 28;
            Theme.StyleButton(br);
            br.Height = 28;
            br.Click += (s, e) =>
            {
                using (OpenFileDialog dlg = new OpenFileDialog())
                {
                    dlg.Filter = "Изображения|*.png;*.jpg;*.jpeg;*.gif|Все файлы|*.*";
                    if (dlg.ShowDialog(this) == DialogResult.OK) tb.Text = dlg.FileName;
                }
            };
            p.Controls.Add(tb);
            p.Controls.Add(br);
            fileBoxes[f.Col] = tb;
            return p;
        }

        TextBox box = new TextBox();
        if (v != null) box.Text = FormatValue(v);
        return box;
    }

    private void Warn(Field f, string msg)
    {
        MessageBox.Show("Поле «" + f.Label + "»: " + msg, "Проверка данных", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }

    private void OnOk()
    {
        Dictionary<string, object> d = new Dictionary<string, object>();
        foreach (Field f in fields)
        {
            object val = null;
            Control c = inputs[f.Col];

            if (f.Kind == Kind.Date)
            {
                DateTimePicker dtp = (DateTimePicker)c;
                if (!dtp.ShowCheckBox || dtp.Checked) val = dtp.Value.Date;
                else if (f.Required) { Warn(f, "укажите дату"); return; }
            }
            else if (f.Kind == Kind.Combo)
            {
                ComboBox cb = (ComboBox)c;
                if (cb.SelectedItem != null) val = cb.SelectedItem.ToString();
            }
            else if (f.Kind == Kind.Lookup)
            {
                ComboItem it = ((ComboBox)c).SelectedItem as ComboItem;
                if (it == null || it.Id < 0)
                {
                    if (f.Required) { Warn(f, "выберите значение из списка"); return; }
                }
                else
                {
                    val = it.Id;
                }
            }
            else
            {
                string s = (f.Kind == Kind.File ? fileBoxes[f.Col].Text : ((TextBox)c).Text).Trim();
                if (s.Length == 0)
                {
                    if (f.Required) { Warn(f, "обязательное поле, заполните его"); return; }
                }
                else if (f.Kind == Kind.Num)
                {
                    decimal m;
                    if (!decimal.TryParse(s.Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out m) || m < 0)
                    { Warn(f, "введите неотрицательное число"); return; }
                    val = m;
                }
                else if (f.Kind == Kind.Int)
                {
                    int n;
                    if (!int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out n) || n < 0)
                    { Warn(f, "введите целое неотрицательное число"); return; }
                    val = n;
                }
                else
                {
                    val = s;
                }
            }
            d[f.Col] = val;
        }

        try
        {
            save(d);
            DialogResult = DialogResult.OK;
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(ex.Message, "Ошибка базы данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
