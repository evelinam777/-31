using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;

namespace Nursery;

/// <summary>Загрузка картинок из папки assets и подбор иллюстрации для растения.</summary>
public static class Assets
{
    private static readonly Dictionary<string, Image> cache = new Dictionary<string, Image>();

    public static string Dir
    {
        get { return Path.Combine(AppContext.BaseDirectory, "assets"); }
    }

    /// <summary>Загружает файл и вписывает его в рамку maxW x maxH. Если файла нет — возвращает null.</summary>
    public static Image Load(string path, int maxW = 0, int maxH = 0)
    {
        string key = path + "|" + maxW + "x" + maxH;
        Image result;
        if (cache.TryGetValue(key, out result)) return result;
        result = null;
        try
        {
            if (File.Exists(path))
            {
                using (Image src = Image.FromFile(path))
                {
                    double k = 1.0;
                    if (maxW > 0 && maxH > 0) k = Math.Min((double)maxW / src.Width, (double)maxH / src.Height);
                    int w = Math.Max(1, (int)(src.Width * k));
                    int h = Math.Max(1, (int)(src.Height * k));
                    Bitmap bmp = new Bitmap(w, h);
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.SmoothingMode = SmoothingMode.HighQuality;
                        g.DrawImage(src, 0, 0, w, h);
                    }
                    result = bmp;
                }
            }
        }
        catch (Exception)
        {
            result = null;
        }
        cache[key] = result;
        return result;
    }

    public static Image Named(string fileName, int maxW = 0, int maxH = 0)
    {
        return Load(Path.Combine(Dir, fileName), maxW, maxH);
    }

    /// <summary>Фото растения; если его нет — иллюстрация по названию или категории.</summary>
    public static Image PlantImage(string name, string category, string photo, int w, int h)
    {
        if (!string.IsNullOrWhiteSpace(photo))
        {
            Image own = Load(photo, w, h);
            if (own != null) return own;
        }
        string n = (name ?? "").ToLowerInvariant();
        string pic = "generic.png";
        if (n.Contains("роз")) pic = "rose.png";
        else if (n.Contains("туя")) pic = "thuja.png";
        else if (n.Contains("гортенз")) pic = "hydrangea.png";
        else if (n.Contains("лаванд")) pic = "lavender.png";
        else if (category == "Хвойные") pic = "thuja.png";
        else if (category == "Кустарники") pic = "hydrangea.png";
        return Named(pic, w, h);
    }
}
