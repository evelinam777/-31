using System.Globalization;
using System.Windows.Forms;

namespace Nursery;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.SetHighDpiMode(HighDpiMode.SystemAware);

        var ru = new CultureInfo("ru-RU");
        CultureInfo.DefaultThreadCurrentCulture = ru;
        CultureInfo.DefaultThreadCurrentUICulture = ru;
        CultureInfo.CurrentCulture = ru;
        CultureInfo.CurrentUICulture = ru;

        // Подготовка базы данных: при первом запуске создаются база nursery и таблицы из schema.sql
        try
        {
            Db.Init();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Не удалось подключиться к базе данных MySQL.\n\n" +
                "Откройте XAMPP Control Panel и нажмите Start напротив MySQL, затем запустите программу снова.\n\n" +
                "Подробности: " + ex.Message,
                "Нет подключения к MySQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        // Цикл: окно входа -> главное окно -> (при выходе из учётной записи) снова окно входа
        while (true)
        {
            using (var login = new LoginForm())
            {
                if (login.ShowDialog() != DialogResult.OK) break;
                using (var main = new MainForm(login.FullName, login.Role))
                {
                    main.ShowDialog();
                    if (!main.Logout) break;
                }
            }
        }
    }
}
