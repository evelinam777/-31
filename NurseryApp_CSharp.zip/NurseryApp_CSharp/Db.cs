using System.Data;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MySqlConnector;

namespace Nursery;

/// <summary>Подключение к MySQL и вспомогательные методы выполнения запросов.</summary>
public static class Db
{
    // --- Настройки подключения (для XAMPP менять ничего не нужно) ---
    public const string Name = "nursery";
    public static string Server = "localhost";
    public static int Port = 3306;
    public static string User = "root";
    public static string Password = "";

    private static string ConnStr(bool withDb)
    {
        string s = "Server=" + Server + ";Port=" + Port + ";User ID=" + User +
                   ";Password=" + Password + ";CharacterSet=utf8mb4;";
        if (withDb) s += "Database=" + Name + ";";
        return s;
    }

    public static MySqlConnection Open(bool withDb = true)
    {
        MySqlConnection c = new MySqlConnection(ConnStr(withDb));
        c.Open();
        return c;
    }

    /// <summary>Создаёт команду; параметры в тексте запроса называются @p0, @p1, ...</summary>
    public static MySqlCommand Cmd(MySqlConnection c, MySqlTransaction tx, string sql, params object[] p)
    {
        MySqlCommand cmd = new MySqlCommand(sql, c, tx);
        for (int i = 0; i < p.Length; i++)
            cmd.Parameters.AddWithValue("@p" + i, p[i] ?? DBNull.Value);
        return cmd;
    }

    /// <summary>Выполняет SELECT и возвращает таблицу с результатом.</summary>
    public static DataTable Table(string sql, params object[] p)
    {
        using (MySqlConnection c = Open())
        using (MySqlCommand cmd = Cmd(c, null, sql, p))
        using (MySqlDataReader r = cmd.ExecuteReader())
        {
            DataTable t = new DataTable();
            bool[] bin = new bool[r.FieldCount];
            for (int i = 0; i < r.FieldCount; i++)
            {
                string n = r.GetName(i);
                if (t.Columns.Contains(n)) n = n + "_" + i;
                Type ft = r.GetFieldType(i);
                if (ft == typeof(byte[])) { ft = typeof(string); bin[i] = true; }
                t.Columns.Add(n, ft);
            }
            object[] vals = new object[r.FieldCount];
            while (r.Read())
            {
                r.GetValues(vals);
                for (int i = 0; i < vals.Length; i++)
                    if (bin[i] && vals[i] is byte[]) vals[i] = Encoding.UTF8.GetString((byte[])vals[i]);
                t.Rows.Add(vals);
            }
            return t;
        }
    }

    public static object Scalar(string sql, params object[] p)
    {
        using (MySqlConnection c = Open())
        using (MySqlCommand cmd = Cmd(c, null, sql, p))
        {
            object v = cmd.ExecuteScalar();
            if (v == null || v is DBNull) return null;
            return v;
        }
    }

    public static int Exec(string sql, params object[] p)
    {
        using (MySqlConnection c = Open())
        using (MySqlCommand cmd = Cmd(c, null, sql, p))
        {
            return cmd.ExecuteNonQuery();
        }
    }

    /// <summary>Список для выпадающего поля: первый столбец — id, второй — подпись.</summary>
    public static List<ComboItem> Lookup(string sql)
    {
        List<ComboItem> list = new List<ComboItem>();
        DataTable t = Table(sql);
        foreach (DataRow r in t.Rows)
            list.Add(new ComboItem { Id = Convert.ToInt32(r[0]), Text = Convert.ToString(r[1]) });
        return list;
    }

    public static string Hash(string s)
    {
        byte[] h = SHA256.HashData(Encoding.UTF8.GetBytes(s));
        return Convert.ToHexString(h).ToLowerInvariant();
    }

    /// <summary>Создаёт базу и таблицы из schema.sql, если их ещё нет (первый запуск).</summary>
    public static void Init()
    {
        using (MySqlConnection c = Open(false))
        {
            object n;
            using (MySqlCommand cmd = Cmd(c, null,
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = @p0 AND table_name = 'app_user'", Name))
            {
                n = cmd.ExecuteScalar();
            }
            if (Convert.ToInt64(n) > 0) return;

            try
            {
                RunScript(c, Path.Combine(AppContext.BaseDirectory, "schema.sql"));
            }
            catch (Exception)
            {
                // Если скрипт не дошёл до конца — удаляем неполную базу, чтобы при следующем запуске создать её заново
                using (MySqlCommand drop = new MySqlCommand("DROP DATABASE IF EXISTS " + Name, c))
                    drop.ExecuteNonQuery();
                throw;
            }
        }
    }

    /// <summary>Выполняет SQL-скрипт с поддержкой команды DELIMITER (нужна для триггеров).</summary>
    private static void RunScript(MySqlConnection c, string path)
    {
        string delim = ";";
        StringBuilder buf = new StringBuilder();
        foreach (string raw in File.ReadAllLines(path, Encoding.UTF8))
        {
            string line = raw.TrimEnd();
            string t = line.Trim();
            if (buf.Length == 0 && (t.Length == 0 || t.StartsWith("--"))) continue;
            if (buf.Length == 0 && t.StartsWith("DELIMITER ", StringComparison.OrdinalIgnoreCase))
            {
                delim = t.Substring(10).Trim();
                continue;
            }
            buf.AppendLine(line);
            if (t.EndsWith(delim))
            {
                string sql = buf.ToString().Trim();
                sql = sql.Substring(0, sql.Length - delim.Length).Trim();
                buf.Clear();
                if (sql.Length > 0)
                {
                    using (MySqlCommand cmd = new MySqlCommand(sql, c))
                        cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
