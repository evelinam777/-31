-- ============================================================================
-- АИС «Питомник растений (оранжерея)». Скрипт базы данных для MySQL / MariaDB
-- Часть 1: структура (таблицы, ключи, триггеры). Данных здесь нет.
-- ============================================================================
CREATE DATABASE IF NOT EXISTS nursery CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nursery;

-- 1. Оранжерея
CREATE TABLE greenhouse (
  id_greenhouse INT AUTO_INCREMENT PRIMARY KEY,
  number        VARCHAR(20)  NOT NULL,
  area          DECIMAL(8,2) NULL,
  type          VARCHAR(40)  NULL,
  temp_min      DECIMAL(5,1) NULL,
  temp_max      DECIMAL(5,1) NULL,
  hum_min       DECIMAL(5,1) NULL,
  hum_max       DECIMAL(5,1) NULL,
  light         VARCHAR(60)  NULL,
  description   VARCHAR(255) NULL
);

-- 2. Растение
CREATE TABLE plant (
  id_plant    INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100)  NOT NULL,
  variety     VARCHAR(100)  NULL,
  category    VARCHAR(40)   NULL,
  unit        VARCHAR(20)   NOT NULL DEFAULT 'шт',
  price       DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  min_stock   INT           NOT NULL DEFAULT 0 CHECK (min_stock >= 0),
  description VARCHAR(255)  NULL,
  photo       VARCHAR(255)  NULL
);

-- 3. Остаток растений
CREATE TABLE stock (
  id_stock      INT AUTO_INCREMENT PRIMARY KEY,
  id_plant      INT NOT NULL,
  id_greenhouse INT NOT NULL,
  quantity      INT NOT NULL CHECK (quantity >= 0),
  updated       DATE NULL,
  UNIQUE KEY uq_stock (id_plant, id_greenhouse),
  FOREIGN KEY (id_plant)      REFERENCES plant(id_plant),
  FOREIGN KEY (id_greenhouse) REFERENCES greenhouse(id_greenhouse)
);

-- 4. Поставщик
CREATE TABLE supplier (
  id_supplier INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  contact     VARCHAR(100) NULL,
  phone       VARCHAR(30)  NULL,
  email       VARCHAR(100) NULL,
  address     VARCHAR(200) NULL,
  note        VARCHAR(255) NULL
);

-- 5. Поступление
CREATE TABLE receipt (
  id_receipt   INT AUTO_INCREMENT PRIMARY KEY,
  id_supplier  INT NOT NULL,
  receipt_date DATE NOT NULL,
  doc_number   VARCHAR(30)  NULL,
  note         VARCHAR(255) NULL,
  FOREIGN KEY (id_supplier) REFERENCES supplier(id_supplier)
);

-- 6. Поступление растений
CREATE TABLE receipt_item (
  id_receipt_item INT AUTO_INCREMENT PRIMARY KEY,
  id_receipt      INT NOT NULL,
  id_plant        INT NOT NULL,
  quantity        INT NOT NULL CHECK (quantity > 0),
  purchase_price  DECIMAL(10,2) NOT NULL CHECK (purchase_price >= 0),
  FOREIGN KEY (id_receipt) REFERENCES receipt(id_receipt),
  FOREIGN KEY (id_plant)   REFERENCES plant(id_plant)
);

-- 7. Покупатель
CREATE TABLE customer (
  id_customer INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  phone       VARCHAR(30)  NULL,
  email       VARCHAR(100) NULL,
  address     VARCHAR(200) NULL,
  note        VARCHAR(255) NULL
);

-- 8. Продажа
CREATE TABLE sale (
  id_sale     INT AUTO_INCREMENT PRIMARY KEY,
  id_customer INT NOT NULL,
  sale_date   DATE NOT NULL,
  doc_number  VARCHAR(30)  NULL,
  payment     VARCHAR(30)  NULL,
  note        VARCHAR(255) NULL,
  FOREIGN KEY (id_customer) REFERENCES customer(id_customer)
);

-- 9. Продажа растений
CREATE TABLE sale_item (
  id_sale_item INT AUTO_INCREMENT PRIMARY KEY,
  id_sale      INT NOT NULL,
  id_plant     INT NOT NULL,
  quantity     INT NOT NULL CHECK (quantity > 0),
  price        DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  discount     DECIMAL(5,2)  NOT NULL DEFAULT 0 CHECK (discount >= 0 AND discount <= 100),
  total        DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (id_sale)  REFERENCES sale(id_sale),
  FOREIGN KEY (id_plant) REFERENCES plant(id_plant)
);

-- 10. Сотрудник
CREATE TABLE employee (
  id_employee INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  job_title   VARCHAR(80)  NULL,
  phone       VARCHAR(30)  NULL,
  email       VARCHAR(100) NULL
);

-- 11. Тип работы
CREATE TABLE work_type (
  id_work_type INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(80)  NOT NULL,
  description  VARCHAR(255) NULL
);

-- 12. Работа по уходу
CREATE TABLE care (
  id_care       INT AUTO_INCREMENT PRIMARY KEY,
  id_plant      INT NOT NULL,
  id_greenhouse INT NULL,
  id_employee   INT NULL,
  id_work_type  INT NOT NULL,
  work_date     DATE NOT NULL,
  quantity      INT NULL,
  result        VARCHAR(40)  NULL,
  comment       VARCHAR(255) NULL,
  FOREIGN KEY (id_plant)      REFERENCES plant(id_plant),
  FOREIGN KEY (id_greenhouse) REFERENCES greenhouse(id_greenhouse),
  FOREIGN KEY (id_employee)   REFERENCES employee(id_employee),
  FOREIGN KEY (id_work_type)  REFERENCES work_type(id_work_type)
);

-- 13. Состояние растений
CREATE TABLE plant_condition (
  id_plant_condition INT AUTO_INCREMENT PRIMARY KEY,
  id_plant           INT NOT NULL,
  check_date         DATE NOT NULL,
  state              VARCHAR(40)  NULL,
  description        VARCHAR(255) NULL,
  recommendation     VARCHAR(255) NULL,
  FOREIGN KEY (id_plant) REFERENCES plant(id_plant)
);

-- 14. Заболевание
CREATE TABLE disease (
  id_disease  INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  description VARCHAR(255) NULL
);

-- 15. Лечение растений
CREATE TABLE treatment (
  id_treatment       INT AUTO_INCREMENT PRIMARY KEY,
  id_plant_condition INT NOT NULL,
  id_disease         INT NOT NULL,
  id_employee        INT NULL,
  treat_date         DATE NOT NULL,
  action             VARCHAR(150) NULL,
  drug               VARCHAR(100) NULL,
  result             VARCHAR(150) NULL,
  next_check         DATE NULL,
  FOREIGN KEY (id_plant_condition) REFERENCES plant_condition(id_plant_condition),
  FOREIGN KEY (id_disease)         REFERENCES disease(id_disease),
  FOREIGN KEY (id_employee)        REFERENCES employee(id_employee)
);

-- 16. Пользователь системы (вход по логину и паролю)
CREATE TABLE app_user (
  id_user       INT AUTO_INCREMENT PRIMARY KEY,
  login         VARCHAR(40) NOT NULL UNIQUE,
  password_hash CHAR(64)    NOT NULL,
  role          VARCHAR(20) NOT NULL,
  full_name     VARCHAR(100) NULL
);

-- ============================================================================
-- ТРИГГЕРЫ
-- ============================================================================
DELIMITER $$

-- Т1. Перед добавлением строки продажи: проверить наличие и рассчитать сумму
CREATE TRIGGER trg_sale_item_bi BEFORE INSERT ON sale_item FOR EACH ROW
BEGIN
  DECLARE v_stock INT;
  SELECT COALESCE(SUM(quantity), 0) INTO v_stock FROM stock WHERE id_plant = NEW.id_plant;
  IF v_stock < NEW.quantity THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Недостаточно растений на складе для продажи';
  END IF;
  SET NEW.total = ROUND(NEW.quantity * NEW.price * (1 - NEW.discount / 100), 2);
END$$

-- Т2. Перед добавлением остатка: проставить дату обновления
CREATE TRIGGER trg_stock_bi BEFORE INSERT ON stock FOR EACH ROW
  SET NEW.updated = IFNULL(NEW.updated, CURDATE())$$

-- Т3. Перед изменением остатка: обновить дату обновления
CREATE TRIGGER trg_stock_bu BEFORE UPDATE ON stock FOR EACH ROW
  SET NEW.updated = CURDATE()$$

-- Т4. Перед удалением растения: запретить, если есть остатки; убрать нулевые строки остатков
CREATE TRIGGER trg_plant_bd BEFORE DELETE ON plant FOR EACH ROW
BEGIN
  IF EXISTS (SELECT 1 FROM stock WHERE id_plant = OLD.id_plant AND quantity > 0) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Нельзя удалить растение: на складе есть остатки';
  END IF;
  DELETE FROM stock WHERE id_plant = OLD.id_plant AND quantity = 0;
END$$

-- Т5. Перед добавлением работы по уходу: если статус не указан, считать работу запланированной
CREATE TRIGGER trg_care_bi BEFORE INSERT ON care FOR EACH ROW
  SET NEW.result = IFNULL(NEW.result, 'Запланировано')$$

DELIMITER ;

-- ===== ДАННЫЕ =====
-- Часть 2: тестовые данные для демонстрации (в пояснительную записку не включаются)
INSERT INTO greenhouse(number,area,type,temp_min,temp_max,hum_min,hum_max,light,description) VALUES
 ('1',120,'Тёплая',18,26,60,80,'Рассеянный','Цветущие и теплолюбивые растения'),
 ('2',200,'Холодная',5,15,50,70,'Яркий','Хвойные и кустарники'),
 ('3',80,'Универсальная',12,22,55,75,'Умеренный','Рассада и комнатные растения');

INSERT INTO plant(name,variety,category,unit,price,min_stock,description) VALUES
 ('Роза','Аваланж','Цветущие','шт',800,20,'Белая чайно-гибридная роза'),
 ('Туя','Смарагд','Хвойные','шт',1200,30,'Колоновидная туя для живой изгороди'),
 ('Гортензия','Анабель','Кустарники','шт',900,15,'Крупные белые соцветия'),
 ('Лаванда','Хидкот','Цветущие','шт',250,40,'Морозостойкая лаванда'),
 ('Можжевельник','Блю Эрроу','Хвойные','шт',1500,10,'Серебристо-голубая хвоя'),
 ('Фикус','Бенджамина','Комнатные','горшок',700,10,'Комнатное растение');

INSERT INTO stock(id_plant,id_greenhouse,quantity) VALUES (1,1,40),(2,2,63),(3,2,12),(4,1,80),(5,2,25),(6,3,8);

INSERT INTO supplier(name,contact,phone,email,address,note) VALUES
 ('ООО «Зелёный мир»','Сидоров Пётр Петрович','+7 900 111-22-33','info@green-mir.ru','г. Москва, ул. Садовая, 12','Хвойные и кустарники'),
 ('ИП Цветкова А.В.','Цветкова Анна Викторовна','+7 900 444-55-66','cvetkova@mail.ru','г. Тула, ул. Цветочная, 5','Цветущие и комнатные растения');

INSERT INTO customer(name,phone,email,address) VALUES
 ('Иванов Иван Иванович','+7 911 222-33-44','ivanov@mail.ru','г. Москва, ул. Лесная, 7'),
 ('Смирнова Ольга Петровна','+7 912 333-44-55',NULL,'г. Тула, пр. Мира, 20'),
 ('ООО «Ландшафт-Про»','+7 495 123-45-67','info@landshaft.ru','г. Москва, ул. Парковая, 3');

INSERT INTO employee(name,job_title,phone) VALUES
 ('Петров А.А.','Агроном','+7 900 777-88-99'),
 ('Кузнецова М.С.','Помощник агронома','+7 900 888-99-00');

INSERT INTO work_type(name,description) VALUES
 ('Полив','Полив растений по графику'),
 ('Внесение удобрений','Подкормка растений'),
 ('Пересадка','Пересадка в новый контейнер или грунт'),
 ('Обработка от вредителей','Обработка препаратами от вредителей и болезней'),
 ('Обрезка','Формирующая и санитарная обрезка');

INSERT INTO disease(name,description) VALUES
 ('Мучнистая роса','Белый налёт на листьях'),
 ('Тля','Вредитель, повреждающий молодые побеги'),
 ('Серая гниль','Грибковое заболевание, поражает цветки и листья'),
 ('Хлороз','Пожелтение листьев из-за недостатка питательных веществ');

INSERT INTO receipt(id_supplier,receipt_date,doc_number) VALUES (1,'2026-09-01','ПС-0001'),(2,'2026-09-05','ПС-0002');
INSERT INTO receipt_item(id_receipt,id_plant,quantity,purchase_price) VALUES (1,2,50,700),(1,5,30,900),(2,1,60,400),(2,4,100,120);

INSERT INTO sale(id_customer,sale_date,doc_number,payment) VALUES
 (1,'2026-09-15','ПР-0001','Карта'),(2,'2026-09-20','ПР-0002','Наличные'),(3,'2026-10-05','ПР-0003','Перевод');
INSERT INTO sale_item(id_sale,id_plant,quantity,price,discount,total) VALUES
 (1,1,3,800,0,2400),(1,2,2,1200,0,2400),
 (2,4,10,250,0,2500),
 (3,2,20,1200,10,21600);

INSERT INTO care(id_plant,id_greenhouse,id_employee,id_work_type,work_date,quantity,result,comment) VALUES
 (2,2,1,1,'2026-09-03',48,'Выполнено','Полив выполнен по графику.'),
 (1,1,1,2,'2026-09-10',40,'Выполнено','Подкормка комплексным удобрением'),
 (2,2,1,1,CURDATE(),48,'Запланировано','Полив по графику'),
 (1,1,2,2,DATE_ADD(CURDATE(), INTERVAL 2 DAY),40,'Запланировано','Подкормка'),
 (3,2,1,4,DATE_ADD(CURDATE(), INTERVAL 5 DAY),12,'Запланировано','Обработка от тли');

INSERT INTO plant_condition(id_plant,check_date,state,description,recommendation) VALUES
 (3,'2026-10-10','Удовлетворительное','Лёгкий налёт на листьях','Обработать фунгицидом'),
 (1,'2026-10-12','Хорошее','Активный рост, бутонизация','Продолжить подкормку');

INSERT INTO treatment(id_plant_condition,id_disease,id_employee,treat_date,action,drug,result,next_check) VALUES
 (1,1,1,'2026-10-11','Опрыскивание','Топаз','Налёт уменьшился',DATE_ADD(CURDATE(), INTERVAL 3 DAY));

INSERT INTO app_user(login,password_hash,role,full_name) VALUES
 ('admin','240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9','admin','Администратор'),
 ('manager','866485796cfa8d7c0cf7111640205b83076433547577511d81f8030ae99ecea5','manager','Менеджер питомника'),
 ('agronom','1d73a48e4b7289ed82247e75afa1966a04eea918c582c1625b7709988c8f73a5','agronomist','Агроном');
