using System.Drawing;
using System.Windows.Forms;

namespace Nursery;

/// <summary>Главное окно: баннер, меню разделов слева и рабочая область справа.</summary>
public class MainForm : Form
{
    public bool Logout;

    private readonly string userName;
    private readonly Panel host = new Panel();
    private Button active;

    public MainForm(string userName, string role)
    {
        this.userName = userName;
        Text = "АИС «Питомник растений»";
        Font = Theme.F(10f);
        BackColor = Color.White;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1260, 740);
        MinimumSize = new Size(1080, 640);

        // Рабочая область (добавляется первой: занимает всё оставшееся место)
        host.Dock = DockStyle.Fill;
        host.BackColor = Color.White;
        Controls.Add(host);

        // Меню разделов
        FlowLayoutPanel side = new FlowLayoutPanel();
        side.Dock = DockStyle.Left;
        side.Width = 250;
        side.FlowDirection = FlowDirection.TopDown;
        side.WrapContents = false;
        side.AutoScroll = true;
        side.BackColor = Theme.GreenLight;
        side.Padding = new Padding(10, 12, 0, 0);
        List<Button> buttons = new List<Button>();
        foreach (string name in Sections.For(role))
        {
            Button b = MakeNavButton(name);
            side.Controls.Add(b);
            buttons.Add(b);
        }
        Controls.Add(side);

        // Зелёная полоса под шапкой
        Panel strip = new Panel();
        strip.Dock = DockStyle.Top;
        strip.Height = 4;
        strip.BackColor = Theme.Green;
        Controls.Add(strip);

        // Шапка с баннером
        Panel header = new Panel();
        header.Dock = DockStyle.Top;
        header.Height = 90;
        header.BackColor = Theme.Pink;
        header.BackgroundImage = Assets.Named("banner.png");
        header.BackgroundImageLayout = ImageLayout.Stretch;

        Label title = new Label();
        title.Text = "Питомник растений";
        title.Left = 20; title.Top = 12; title.AutoSize = true;
        title.BackColor = Color.Transparent;
        title.ForeColor = Color.White;
        title.Font = Theme.F(22f, FontStyle.Bold);
        header.Controls.Add(title);

        Label sub = new Label();
        sub.Text = "Свежие растения · забота · порядок";
        sub.Left = 24; sub.Top = 58; sub.AutoSize = true;
        sub.BackColor = Color.Transparent;
        sub.ForeColor = Color.White;
        sub.Font = Theme.F(10f, FontStyle.Italic);
        header.Controls.Add(sub);

        Label who = new Label();
        who.Text = userName + " · " + Sections.RoleName(role);
        who.AutoSize = true;
        who.Top = 14;
        who.BackColor = Color.Transparent;
        who.ForeColor = Color.White;
        who.Font = Theme.F(11f, FontStyle.Bold);
        header.Controls.Add(who);

        Button exit = new Button();
        exit.Text = "Выйти";
        exit.Width = 110;
        exit.Top = 46;
        Theme.StyleButton(exit, true);
        exit.Click += (s, e) => { Logout = true; Close(); };
        header.Controls.Add(exit);

        header.SizeChanged += (s, e) =>
        {
            who.Left = header.Width - who.Width - 20;
            exit.Left = header.Width - exit.Width - 20;
        };
        Controls.Add(header);

        if (buttons.Count > 0) ShowSection(buttons[0]);
    }

    private Button MakeNavButton(string name)
    {
        Button b = new Button();
        b.Text = name;
        b.Tag = name;
        b.Width = 212;
        b.Height = 40;
        b.Margin = new Padding(0, 0, 0, 5);
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.UseVisualStyleBackColor = false;
        b.TextAlign = ContentAlignment.MiddleLeft;
        b.Padding = new Padding(14, 0, 0, 0);
        b.Font = Theme.F(10.5f, FontStyle.Bold);
        b.Cursor = Cursors.Hand;
        SetNormal(b);
        b.MouseEnter += (s, e) => { if (b != active) b.BackColor = Theme.PinkLight; };
        b.MouseLeave += (s, e) => { if (b != active) b.BackColor = Color.White; };
        b.Click += (s, e) => ShowSection(b);
        return b;
    }

    private static void SetNormal(Button b)
    {
        b.BackColor = Color.White;
        b.ForeColor = Theme.Green;
    }

    private void ShowSection(Button b)
    {
        Control content;
        try
        {
            content = Sections.Create((string)b.Tag, userName);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Ошибка при открытии раздела", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        if (active != null) SetNormal(active);
        active = b;
        b.BackColor = Theme.Pink;
        b.ForeColor = Color.White;

        foreach (Control old in host.Controls.Cast<Control>().ToList())
        {
            host.Controls.Remove(old);
            old.Dispose();
        }
        content.Dock = DockStyle.Fill;
        host.Controls.Add(content);
    }
}
