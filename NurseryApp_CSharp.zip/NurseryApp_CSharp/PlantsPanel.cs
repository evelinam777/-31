using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Nursery;

/// <summary>Каталог растений: таблица слева и карточка с фотографией выбранного растения справа.</summary>
public class PlantsPanel : UserControl
{
    private readonly CrudPanel crud;
    private readonly PictureBox pic = new PictureBox();
    private readonly Label title = new Label();
    private readonly Label info = new Label();

    public PlantsPanel()
    {
        BackColor = Color.White;

        crud = new CrudPanel("plant", "id_plant", Sections.PlantFields,
            "SELECT id_plant, name, variety, category, unit, price, min_stock FROM plant ORDER BY name",
            new string[] { "Название", "Сорт", "Категория", "Ед.", "Цена, ₽", "Мин. остаток" });
        crud.Dock = DockStyle.Fill;
        Controls.Add(crud);

        Panel card = new Panel();
        card.Dock = DockStyle.Right;
        card.Width = 270;
        card.BackColor = Theme.PinkLight;
        card.Padding = new Padding(8);

        pic.Left = 20; pic.Top = 20; pic.Width = 230; pic.Height = 230;
        pic.SizeMode = PictureBoxSizeMode.CenterImage;
        pic.BackColor = Theme.PinkLight;
        card.Controls.Add(pic);

        title.Left = 10; title.Top = 258; title.Width = 250; title.Height = 54;
        title.Font = Theme.F(13f, FontStyle.Bold);
        title.ForeColor = Theme.PinkDark;
        title.TextAlign = ContentAlignment.MiddleCenter;
        card.Controls.Add(title);

        info.Left = 14; info.Top = 318; info.Width = 244; info.Height = 220;
        info.Font = Theme.F(10f);
        info.ForeColor = Theme.Green;
        card.Controls.Add(info);
        Controls.Add(card);

        crud.Grid.SelectionChanged += (s, e) => ShowInfo();
        ShowInfo();
    }

    private void ShowInfo()
    {
        int id = crud.SelectedId();
        if (id < 0)
        {
            pic.Image = Assets.PlantImage("", "", null, 220, 220);
            title.Text = "Выберите растение";
            info.Text = "Фотография и сведения о растении появятся здесь.";
            return;
        }
        DataTable t = Db.Table(
            "SELECT name, variety, category, price, unit, description, photo, " +
            "(SELECT COALESCE(SUM(quantity), 0) FROM stock WHERE stock.id_plant = plant.id_plant) AS qty, min_stock " +
            "FROM plant WHERE id_plant = @p0", id);
        if (t.Rows.Count == 0) return;
        DataRow r = t.Rows[0];
        string name = Convert.ToString(r[0]);
        string variety = Convert.ToString(r[1]);
        string category = Convert.ToString(r[2]);
        decimal price = Convert.ToDecimal(r[3]);
        string unit = Convert.ToString(r[4]);
        string desc = Convert.ToString(r[5]);
        string photo = Convert.ToString(r[6]);
        int qty = Convert.ToInt32(r[7]);
        int min = Convert.ToInt32(r[8]);

        pic.Image = Assets.PlantImage(name, category, photo, 220, 220);
        title.Text = string.IsNullOrEmpty(variety) ? name : name + " «" + variety + "»";
        string text = "Категория: " + category + "\n" +
                      "Цена: " + price.ToString("0.##") + " ₽ / " + unit + "\n" +
                      "На складе: " + qty + " (минимум " + min + ")";
        if (qty <= min) text += "\nВнимание: низкий остаток!";
        if (!string.IsNullOrEmpty(desc)) text += "\n\n" + desc;
        info.Text = text;
    }
}
