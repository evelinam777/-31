-- ============================================================================
-- АИС «Питомник растений (оранжерея)». Скрипт базы данных для MySQL / MariaDB
-- Часть 1: структура (таблицы, ключи, триггеры). Данных здесь нет.
-- ============================================================================
CREATE DATABASE IF NOT EXISTS nursery CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nursery;

-- 1. Оранжерея
CREATE TABLE greenhouse (
  id_greenhouse INT AUTO_INCREMENT PRIMARY KEY,
  number        VARCHAR(20)  NOT NULL,
  area          DECIMAL(8,2) NULL,
  type          VARCHAR(40)  NULL,
  temp_min      DECIMAL(5,1) NULL,
  temp_max      DECIMAL(5,1) NULL,
  hum_min       DECIMAL(5,1) NULL,
  hum_max       DECIMAL(5,1) NULL,
  light         VARCHAR(60)  NULL,
  description   VARCHAR(255) NULL
);

-- 2. Растение
CREATE TABLE plant (
  id_plant    INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100)  NOT NULL,
  variety     VARCHAR(100)  NULL,
  category    VARCHAR(40)   NULL,
  unit        VARCHAR(20)   NOT NULL DEFAULT 'шт',
  price       DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  min_stock   INT           NOT NULL DEFAULT 0 CHECK (min_stock >= 0),
  description VARCHAR(255)  NULL,
  photo       VARCHAR(255)  NULL
);

-- 3. Остаток растений
CREATE TABLE stock (
  id_stock      INT AUTO_INCREMENT PRIMARY KEY,
  id_plant      INT NOT NULL,
  id_greenhouse INT NOT NULL,
  quantity      INT NOT NULL CHECK (quantity >= 0),
  updated       DATE NULL,
  UNIQUE KEY uq_stock (id_plant, id_greenhouse),
  FOREIGN KEY (id_plant)      REFERENCES plant(id_plant),
  FOREIGN KEY (id_greenhouse) REFERENCES greenhouse(id_greenhouse)
);

-- 4. Поставщик
CREATE TABLE supplier (
  id_supplier INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  contact     VARCHAR(100) NULL,
  phone       VARCHAR(30)  NULL,
  email       VARCHAR(100) NULL,
  address     VARCHAR(200) NULL,
  note        VARCHAR(255) NULL
);

-- 5. Поступление
CREATE TABLE receipt (
  id_receipt   INT AUTO_INCREMENT PRIMARY KEY,
  id_supplier  INT NOT NULL,
  receipt_date DATE NOT NULL,
  doc_number   VARCHAR(30)  NULL,
  note         VARCHAR(255) NULL,
  FOREIGN KEY (id_supplier) REFERENCES supplier(id_supplier)
);

-- 6. Поступление растений
CREATE TABLE receipt_item (
  id_receipt_item INT AUTO_INCREMENT PRIMARY KEY,
  id_receipt      INT NOT NULL,
  id_plant        INT NOT NULL,
  quantity        INT NOT NULL CHECK (quantity > 0),
  purchase_price  DECIMAL(10,2) NOT NULL CHECK (purchase_price >= 0),
  FOREIGN KEY (id_receipt) REFERENCES receipt(id_receipt),
  FOREIGN KEY (id_plant)   REFERENCES plant(id_plant)
);

-- 7. Покупатель
CREATE TABLE customer (
  id_customer INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  phone       VARCHAR(30)  NULL,
  email       VARCHAR(100) NULL,
  address     VARCHAR(200) NULL,
  note        VARCHAR(255) NULL
);

-- 8. Продажа
CREATE TABLE sale (
  id_sale     INT AUTO_INCREMENT PRIMARY KEY,
  id_customer INT NOT NULL,
  sale_date   DATE NOT NULL,
  doc_number  VARCHAR(30)  NULL,
  payment     VARCHAR(30)  NULL,
  note        VARCHAR(255) NULL,
  FOREIGN KEY (id_customer) REFERENCES customer(id_customer)
);

-- 9. Продажа растений
CREATE TABLE sale_item (
  id_sale_item INT AUTO_INCREMENT PRIMARY KEY,
  id_sale      INT NOT NULL,
  id_plant     INT NOT NULL,
  quantity     INT NOT NULL CHECK (quantity > 0),
  price        DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  discount     DECIMAL(5,2)  NOT NULL DEFAULT 0 CHECK (discount >= 0 AND discount <= 100),
  total        DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (id_sale)  REFERENCES sale(id_sale),
  FOREIGN KEY (id_plant) REFERENCES plant(id_plant)
);

-- 10. Сотрудник
CREATE TABLE employee (
  id_employee INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  job_title   VARCHAR(80)  NULL,
  phone       VARCHAR(30)  NULL,
  email       VARCHAR(100) NULL
);

-- 11. Тип работы
CREATE TABLE work_type (
  id_work_type INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(80)  NOT NULL,
  description  VARCHAR(255) NULL
);

-- 12. Работа по уходу
CREATE TABLE care (
  id_care       INT AUTO_INCREMENT PRIMARY KEY,
  id_plant      INT NOT NULL,
  id_greenhouse INT NULL,
  id_employee   INT NULL,
  id_work_type  INT NOT NULL,
  work_date     DATE NOT NULL,
  quantity      INT NULL,
  result        VARCHAR(40)  NULL,
  comment       VARCHAR(255) NULL,
  FOREIGN KEY (id_plant)      REFERENCES plant(id_plant),
  FOREIGN KEY (id_greenhouse) REFERENCES greenhouse(id_greenhouse),
  FOREIGN KEY (id_employee)   REFERENCES employee(id_employee),
  FOREIGN KEY (id_work_type)  REFERENCES work_type(id_work_type)
);

-- 13. Состояние растений
CREATE TABLE plant_condition (
  id_plant_condition INT AUTO_INCREMENT PRIMARY KEY,
  id_plant           INT NOT NULL,
  check_date         DATE NOT NULL,
  state              VARCHAR(40)  NULL,
  description        VARCHAR(255) NULL,
  recommendation     VARCHAR(255) NULL,
  FOREIGN KEY (id_plant) REFERENCES plant(id_plant)
);

-- 14. Заболевание
CREATE TABLE disease (
  id_disease  INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  description VARCHAR(255) NULL
);

-- 15. Лечение растений
CREATE TABLE treatment (
  id_treatment       INT AUTO_INCREMENT PRIMARY KEY,
  id_plant_condition INT NOT NULL,
  id_disease         INT NOT NULL,
  id_employee        INT NULL,
  treat_date         DATE NOT NULL,
  action             VARCHAR(150) NULL,
  drug               VARCHAR(100) NULL,
  result             VARCHAR(150) NULL,
  next_check         DATE NULL,
  FOREIGN KEY (id_plant_condition) REFERENCES plant_condition(id_plant_condition),
  FOREIGN KEY (id_disease)         REFERENCES disease(id_disease),
  FOREIGN KEY (id_employee)        REFERENCES employee(id_employee)
);

-- 16. Пользователь системы (вход по логину и паролю)
CREATE TABLE app_user (
  id_user       INT AUTO_INCREMENT PRIMARY KEY,
  login         VARCHAR(40) NOT NULL UNIQUE,
  password_hash CHAR(64)    NOT NULL,
  role          VARCHAR(20) NOT NULL,
  full_name     VARCHAR(100) NULL
);

-- ============================================================================
-- ТРИГГЕРЫ
-- ============================================================================
DELIMITER $$

-- Т1. Перед добавлением строки продажи: проверить наличие и рассчитать сумму
CREATE TRIGGER trg_sale_item_bi BEFORE INSERT ON sale_item FOR EACH ROW
BEGIN
  DECLARE v_stock INT;
  SELECT COALESCE(SUM(quantity), 0) INTO v_stock FROM stock WHERE id_plant = NEW.id_plant;
  IF v_stock < NEW.quantity THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Недостаточно растений на складе для продажи';
  END IF;
  SET NEW.total = ROUND(NEW.quantity * NEW.price * (1 - NEW.discount / 100), 2);
END$$

-- Т2. Перед добавлением остатка: проставить дату обновления
CREATE TRIGGER trg_stock_bi BEFORE INSERT ON stock FOR EACH ROW
  SET NEW.updated = IFNULL(NEW.updated, CURDATE())$$

-- Т3. Перед изменением остатка: обновить дату обновления
CREATE TRIGGER trg_stock_bu BEFORE UPDATE ON stock FOR EACH ROW
  SET NEW.updated = CURDATE()$$

-- Т4. Перед удалением растения: запретить, если есть остатки; убрать нулевые строки остатков
CREATE TRIGGER trg_plant_bd BEFORE DELETE ON plant FOR EACH ROW
BEGIN
  IF EXISTS (SELECT 1 FROM stock WHERE id_plant = OLD.id_plant AND quantity > 0) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Нельзя удалить растение: на складе есть остатки';
  END IF;
  DELETE FROM stock WHERE id_plant = OLD.id_plant AND quantity = 0;
END$$

-- Т5. Перед добавлением работы по уходу: если статус не указан, считать работу запланированной
CREATE TRIGGER trg_care_bi BEFORE INSERT ON care FOR EACH ROW
  SET NEW.result = IFNULL(NEW.result, 'Запланировано')$$

DELIMITER ;
