namespace Nursery;

/// <summary>Тип поля в универсальной форме добавления / изменения.</summary>
public enum Kind { Text, Num, Int, Date, Combo, Lookup, File }

/// <summary>Элемент выпадающего списка: идентификатор записи и подпись.</summary>
public class ComboItem
{
    public int Id;
    public string Text;
    public override string ToString() { return Text; }
}

/// <summary>Описание одного поля формы: столбец таблицы, подпись, тип.</summary>
public class Field
{
    public string Col;
    public string Label;
    public Kind Kind;
    public bool Required;
    public string[] Items;
    public string Sql;

    public static Field Text(string col, string label, bool req = false)
    {
        return new Field { Col = col, Label = label, Kind = Kind.Text, Required = req };
    }
    public static Field Num(string col, string label, bool req = false)
    {
        return new Field { Col = col, Label = label, Kind = Kind.Num, Required = req };
    }
    public static Field Int(string col, string label, bool req = false)
    {
        return new Field { Col = col, Label = label, Kind = Kind.Int, Required = req };
    }
    public static Field Date(string col, string label, bool req = false)
    {
        return new Field { Col = col, Label = label, Kind = Kind.Date, Required = req };
    }
    public static Field Combo(string col, string label, string[] items, bool req = false)
    {
        return new Field { Col = col, Label = label, Kind = Kind.Combo, Items = items, Required = req };
    }
    public static Field Lookup(string col, string label, string sql, bool req = false)
    {
        return new Field { Col = col, Label = label, Kind = Kind.Lookup, Sql = sql, Required = req };
    }
    public static Field File(string col, string label)
    {
        return new Field { Col = col, Label = label, Kind = Kind.File };
    }
}
