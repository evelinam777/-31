using System.Drawing;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace Nursery;

/// <summary>Описание всех разделов программы: таблицы, поля форм, отчёты, состав меню по ролям.</summary>
public static class Sections
{
    // --- Запросы для выпадающих списков (идентификатор, подпись) ---
    private const string QPlant =
        "SELECT id_plant, CONCAT(name, CASE WHEN variety IS NULL OR variety = '' THEN '' ELSE CONCAT(' «', variety, '»') END) FROM plant ORDER BY name";
    private const string QGreenhouse =
        "SELECT id_greenhouse, CONCAT('№', number, ' (', COALESCE(type, ''), ')') FROM greenhouse ORDER BY number";
    private const string QEmployee = "SELECT id_employee, name FROM employee ORDER BY name";
    private const string QWorkType = "SELECT id_work_type, name FROM work_type ORDER BY name";
    private const string QDisease = "SELECT id_disease, name FROM disease ORDER BY name";
    private const string QCondition =
        "SELECT c.id_plant_condition, CONCAT(p.name, ' · ', DATE_FORMAT(c.check_date, '%d.%m.%Y')) " +
        "FROM plant_condition c JOIN plant p ON p.id_plant = c.id_plant ORDER BY c.check_date DESC";

    private static readonly string[] Categories = { "Цветущие", "Хвойные", "Лиственные", "Кустарники", "Комнатные", "Плодовые" };

    public static readonly Field[] PlantFields =
    {
        Field.Text("name", "Название", true),
        Field.Text("variety", "Сорт"),
        Field.Combo("category", "Категория", Categories, true),
        Field.Combo("unit", "Единица измерения", new string[] { "шт", "кг", "горшок" }, true),
        Field.Num("price", "Цена продажи, ₽", true),
        Field.Int("min_stock", "Минимальный остаток", true),
        Field.Text("description", "Описание"),
        Field.File("photo", "Фото (необязательно)")
    };

    // --- Меню по ролям ---
    private static readonly string[] ManagerMenu =
        { "Главная", "Растения", "Оранжереи", "Поставщики", "Поступления", "Покупатели", "Продажи", "Остатки", "Отчёты" };

    private static readonly string[] AgronomistMenu =
        { "Главная", "План работ", "Работы по уходу", "Состояние растений", "Лечение", "Заболевания",
          "Растения", "Оранжереи", "Остатки", "Сотрудники", "Типы работ", "Отчёты агронома" };

    public static string[] For(string role)
    {
        if (role == "manager") return ManagerMenu;
        if (role == "agronomist") return AgronomistMenu;
        // Администратор: все разделы без повторов
        List<string> all = new List<string>(ManagerMenu);
        foreach (string s in AgronomistMenu) if (!all.Contains(s)) all.Add(s);
        return all.ToArray();
    }

    public static string RoleName(string role)
    {
        if (role == "manager") return "менеджер";
        if (role == "agronomist") return "агроном";
        return "администратор";
    }

    // --- Отчёты ---
    private const string SaleJoin =
        "FROM sale s JOIN sale_item si ON si.id_sale = s.id_sale JOIN plant p ON p.id_plant = si.id_plant JOIN customer c ON c.id_customer = s.id_customer ";

    private static readonly ReportDef[] ManagerReports =
    {
        new ReportDef("Остатки растений",
            "SELECT p.name, p.variety, g.number, s.quantity, p.price FROM stock s " +
            "JOIN plant p ON p.id_plant = s.id_plant JOIN greenhouse g ON g.id_greenhouse = s.id_greenhouse ORDER BY p.name",
            new string[] { "Название", "Сорт", "Оранжерея", "Количество", "Цена, ₽" }, false, false),
        new ReportDef("Поступления за период",
            "SELECT r.receipt_date, r.doc_number, sp.name, p.name, ri.quantity, ri.purchase_price, ri.quantity * ri.purchase_price " +
            "FROM receipt r JOIN supplier sp ON sp.id_supplier = r.id_supplier JOIN receipt_item ri ON ri.id_receipt = r.id_receipt " +
            "JOIN plant p ON p.id_plant = ri.id_plant WHERE r.receipt_date BETWEEN @p0 AND @p1 ORDER BY r.receipt_date",
            new string[] { "Дата", "№ документа", "Поставщик", "Растение", "Кол-во", "Цена закупки", "Сумма" }, true, true),
        new ReportDef("Продажи за период",
            "SELECT s.sale_date, s.doc_number, c.name, p.name, si.quantity, si.price, si.discount, si.total " + SaleJoin +
            "WHERE s.sale_date BETWEEN @p0 AND @p1 ORDER BY s.sale_date",
            new string[] { "Дата", "№ документа", "Покупатель", "Растение", "Кол-во", "Цена", "Скидка, %", "Сумма" }, true, true),
        new ReportDef("Продажи по растениям (за период)",
            "SELECT p.name, p.variety, SUM(si.quantity), SUM(si.total) " + SaleJoin +
            "WHERE s.sale_date BETWEEN @p0 AND @p1 GROUP BY p.id_plant, p.name, p.variety ORDER BY SUM(si.total) DESC",
            new string[] { "Растение", "Сорт", "Продано, шт", "Выручка" }, true, true),
        new ReportDef("Продажи по покупателям (за период)",
            "SELECT c.name, COUNT(DISTINCT s.id_sale), MAX(s.sale_date), SUM(si.total) " + SaleJoin +
            "WHERE s.sale_date BETWEEN @p0 AND @p1 GROUP BY c.id_customer, c.name ORDER BY SUM(si.total) DESC",
            new string[] { "Покупатель", "Покупок", "Последняя покупка", "Сумма" }, true, true),
        new ReportDef("Наиболее продаваемые растения",
            "SELECT p.name, p.variety, SUM(si.quantity) AS sold FROM sale_item si JOIN plant p ON p.id_plant = si.id_plant " +
            "GROUP BY p.id_plant, p.name, p.variety ORDER BY sold DESC LIMIT 10",
            new string[] { "Растение", "Сорт", "Продано, шт" }, false, false),
        new ReportDef("Растения с низким остатком",
            "SELECT p.name, p.variety, COALESCE(SUM(s.quantity), 0) AS q, p.min_stock FROM plant p " +
            "LEFT JOIN stock s ON s.id_plant = p.id_plant GROUP BY p.id_plant, p.name, p.variety, p.min_stock " +
            "HAVING q <= p.min_stock ORDER BY q",
            new string[] { "Растение", "Сорт", "Остаток", "Минимальный остаток" }, false, false),
        new ReportDef("Список поставщиков",
            "SELECT name, contact, phone, email, address, note FROM supplier ORDER BY name",
            new string[] { "Название", "Контактное лицо", "Телефон", "Email", "Адрес", "Продукция" }, false, false)
    };

    private static readonly ReportDef[] AgronomistReports =
    {
        new ReportDef("План работ на 7 дней",
            "SELECT c.work_date, p.name, w.name, e.name, c.quantity, c.comment FROM care c " +
            "JOIN plant p ON p.id_plant = c.id_plant JOIN work_type w ON w.id_work_type = c.id_work_type " +
            "LEFT JOIN employee e ON e.id_employee = c.id_employee " +
            "WHERE c.result = 'Запланировано' AND c.work_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) ORDER BY c.work_date",
            new string[] { "Дата", "Растение", "Работа", "Сотрудник", "Кол-во", "Комментарий" }, false, false),
        new ReportDef("Работы по уходу за период",
            "SELECT c.work_date, p.name, w.name, g.number, e.name, c.quantity, c.result FROM care c " +
            "JOIN plant p ON p.id_plant = c.id_plant JOIN work_type w ON w.id_work_type = c.id_work_type " +
            "LEFT JOIN greenhouse g ON g.id_greenhouse = c.id_greenhouse LEFT JOIN employee e ON e.id_employee = c.id_employee " +
            "WHERE c.work_date BETWEEN @p0 AND @p1 ORDER BY c.work_date",
            new string[] { "Дата", "Растение", "Работа", "Оранжерея", "Сотрудник", "Кол-во", "Статус" }, true, false),
        new ReportDef("Контроль лечения на 7 дней",
            "SELECT t.next_check, p.name, d.name, t.drug, t.result FROM treatment t " +
            "JOIN plant_condition pc ON pc.id_plant_condition = t.id_plant_condition JOIN plant p ON p.id_plant = pc.id_plant " +
            "JOIN disease d ON d.id_disease = t.id_disease " +
            "WHERE t.next_check IS NOT NULL AND t.next_check <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) ORDER BY t.next_check",
            new string[] { "Следующий контроль", "Растение", "Заболевание", "Препарат", "Результат" }, false, false)
    };

    // --- Подробности по двойному клику ---
    private static string DocDetails(string sql, int id)
    {
        DataTable t = Db.Table(sql, id);
        if (t.Rows.Count == 0) return "Нет позиций";
        StringBuilder sb = new StringBuilder();
        foreach (DataRow r in t.Rows)
            sb.AppendLine(string.Format("{0}: {1} × {2:0.##} ₽ = {3:0.00} ₽", r[0], r[1], r[2], r[3]));
        return sb.ToString();
    }

    private static string CustomerDetails(int id)
    {
        DataTable t = Db.Table(
            "SELECT s.id_sale, s.sale_date, p.name, si.quantity, si.total FROM sale s " +
            "JOIN sale_item si ON si.id_sale = s.id_sale JOIN plant p ON p.id_plant = si.id_plant " +
            "WHERE s.id_customer = @p0 ORDER BY s.sale_date DESC, s.id_sale DESC", id);
        if (t.Rows.Count == 0) return "Покупок пока нет.";

        int lastSale = Convert.ToInt32(t.Rows[0][0]);
        DateTime lastDate = Convert.ToDateTime(t.Rows[0][1]);
        List<string> bought = new List<string>();
        decimal lastSum = 0, allSum = 0;
        List<int> sales = new List<int>();
        foreach (DataRow r in t.Rows)
        {
            decimal tot = Convert.ToDecimal(r[4]);
            allSum += tot;
            int sid = Convert.ToInt32(r[0]);
            if (!sales.Contains(sid)) sales.Add(sid);
            if (sid == lastSale)
            {
                bought.Add(Convert.ToString(r[3]) + " × " + Convert.ToString(r[2]));
                lastSum += tot;
            }
        }
        return "Последняя покупка — " + lastDate.ToString("dd.MM.yyyy") + "\n" +
               "Куплено — " + string.Join(", ", bought) + "\n" +
               "Сумма покупки — " + lastSum.ToString("N2") + " ₽\n\n" +
               "Всего покупок: " + sales.Count + " на сумму " + allSum.ToString("N2") + " ₽";
    }

    // --- Создание раздела по названию ---
    public static Control Create(string name, string userName)
    {
        switch (name)
        {
            case "Главная":
                return new HomePanel(userName);

            case "Растения":
                return new PlantsPanel();

            case "Оранжереи":
                return new CrudPanel("greenhouse", "id_greenhouse",
                    new Field[]
                    {
                        Field.Text("number", "Номер", true),
                        Field.Num("area", "Площадь, м²"),
                        Field.Combo("type", "Тип", new string[] { "Тёплая", "Холодная", "Универсальная" }),
                        Field.Num("temp_min", "Температура мин., °C"),
                        Field.Num("temp_max", "Температура макс., °C"),
                        Field.Num("hum_min", "Влажность мин., %"),
                        Field.Num("hum_max", "Влажность макс., %"),
                        Field.Text("light", "Освещение"),
                        Field.Text("description", "Описание")
                    },
                    "SELECT id_greenhouse, number, area, type, temp_min, temp_max, hum_min, hum_max, light FROM greenhouse ORDER BY number",
                    new string[] { "№", "Площадь, м²", "Тип", "t мин.", "t макс.", "Влажность мин.", "Влажность макс.", "Освещение" });

            case "Поставщики":
                return new CrudPanel("supplier", "id_supplier",
                    new Field[]
                    {
                        Field.Text("name", "Название", true),
                        Field.Text("contact", "Контактное лицо"),
                        Field.Text("phone", "Телефон"),
                        Field.Text("email", "Email"),
                        Field.Text("address", "Адрес"),
                        Field.Text("note", "Вид продукции / примечание")
                    },
                    "SELECT id_supplier, name, contact, phone, email, address, note FROM supplier ORDER BY name",
                    new string[] { "Название", "Контактное лицо", "Телефон", "Email", "Адрес", "Продукция" });

            case "Поступления":
            {
                CrudPanel p = new CrudPanel("receipt", "id_receipt", new Field[0],
                    "SELECT r.id_receipt, r.receipt_date, r.doc_number, s.name, " +
                    "(SELECT COALESCE(SUM(quantity * purchase_price), 0) FROM receipt_item WHERE id_receipt = r.id_receipt) " +
                    "FROM receipt r JOIN supplier s ON s.id_supplier = r.id_supplier ORDER BY r.receipt_date DESC, r.id_receipt DESC",
                    new string[] { "Дата", "№ документа", "Поставщик", "Сумма, ₽" }, true, false, false);
                p.AddOverride = done => { using (DocForm f = new DocForm(false, done)) f.ShowDialog(p.FindForm()); };
                p.Details = id => DocDetails(
                    "SELECT p.name, ri.quantity, ri.purchase_price, ri.quantity * ri.purchase_price FROM receipt_item ri " +
                    "JOIN plant p ON p.id_plant = ri.id_plant WHERE ri.id_receipt = @p0", id);
                return p;
            }

            case "Покупатели":
            {
                CrudPanel p = new CrudPanel("customer", "id_customer",
                    new Field[]
                    {
                        Field.Text("name", "ФИО / название", true),
                        Field.Text("phone", "Телефон"),
                        Field.Text("email", "Email"),
                        Field.Text("address", "Адрес"),
                        Field.Text("note", "Примечание")
                    },
                    "SELECT id_customer, name, phone, email, address FROM customer ORDER BY name",
                    new string[] { "ФИО / название", "Телефон", "Email", "Адрес" });
                p.Details = CustomerDetails;
                return p;
            }

            case "Продажи":
            {
                CrudPanel p = new CrudPanel("sale", "id_sale", new Field[0],
                    "SELECT s.id_sale, s.sale_date, s.doc_number, c.name, s.payment, " +
                    "(SELECT COALESCE(SUM(total), 0) FROM sale_item WHERE id_sale = s.id_sale) " +
                    "FROM sale s JOIN customer c ON c.id_customer = s.id_customer ORDER BY s.sale_date DESC, s.id_sale DESC",
                    new string[] { "Дата", "№ документа", "Покупатель", "Оплата", "Сумма, ₽" }, true, false, false);
                p.AddOverride = done => { using (DocForm f = new DocForm(true, done)) f.ShowDialog(p.FindForm()); };
                p.Details = id => DocDetails(
                    "SELECT p.name, si.quantity, si.price, si.total FROM sale_item si " +
                    "JOIN plant p ON p.id_plant = si.id_plant WHERE si.id_sale = @p0", id);
                return p;
            }

            case "Остатки":
                return new CrudPanel("stock", "id_stock",
                    new Field[]
                    {
                        Field.Lookup("id_plant", "Растение", QPlant, true),
                        Field.Lookup("id_greenhouse", "Оранжерея", QGreenhouse, true),
                        Field.Int("quantity", "Количество", true)
                    },
                    "SELECT s.id_stock, p.name, p.variety, g.number, s.quantity, p.price, s.updated, " +
                    "CASE WHEN s.quantity <= p.min_stock THEN 'low' ELSE '' END " +
                    "FROM stock s JOIN plant p ON p.id_plant = s.id_plant JOIN greenhouse g ON g.id_greenhouse = s.id_greenhouse ORDER BY p.name",
                    new string[] { "Растение", "Сорт", "Оранжерея", "Количество", "Цена, ₽", "Обновлено" });

            case "Отчёты":
                return new ReportsPanel(ManagerReports);

            case "Отчёты агронома":
                return new ReportsPanel(AgronomistReports);

            case "Сотрудники":
                return new CrudPanel("employee", "id_employee",
                    new Field[]
                    {
                        Field.Text("name", "ФИО", true),
                        Field.Text("job_title", "Должность"),
                        Field.Text("phone", "Телефон"),
                        Field.Text("email", "Email")
                    },
                    "SELECT id_employee, name, job_title, phone, email FROM employee ORDER BY name",
                    new string[] { "ФИО", "Должность", "Телефон", "Email" });

            case "Типы работ":
                return new CrudPanel("work_type", "id_work_type",
                    new Field[] { Field.Text("name", "Название", true), Field.Text("description", "Описание") },
                    "SELECT id_work_type, name, description FROM work_type ORDER BY name",
                    new string[] { "Название", "Описание" });

            case "Заболевания":
                return new CrudPanel("disease", "id_disease",
                    new Field[] { Field.Text("name", "Название", true), Field.Text("description", "Описание") },
                    "SELECT id_disease, name, description FROM disease ORDER BY name",
                    new string[] { "Название", "Описание" });

            case "Работы по уходу":
                return new CrudPanel("care", "id_care",
                    new Field[]
                    {
                        Field.Lookup("id_plant", "Растение", QPlant, true),
                        Field.Lookup("id_greenhouse", "Оранжерея", QGreenhouse),
                        Field.Lookup("id_employee", "Сотрудник", QEmployee),
                        Field.Lookup("id_work_type", "Вид работы", QWorkType, true),
                        Field.Date("work_date", "Дата работы", true),
                        Field.Int("quantity", "Количество растений"),
                        Field.Combo("result", "Статус", new string[] { "Запланировано", "Выполнено", "Отменено" }, true),
                        Field.Text("comment", "Комментарий")
                    },
                    "SELECT c.id_care, c.work_date, p.name, g.number, w.name, e.name, c.quantity, c.result FROM care c " +
                    "JOIN plant p ON p.id_plant = c.id_plant LEFT JOIN greenhouse g ON g.id_greenhouse = c.id_greenhouse " +
                    "JOIN work_type w ON w.id_work_type = c.id_work_type LEFT JOIN employee e ON e.id_employee = c.id_employee " +
                    "ORDER BY c.work_date DESC, c.id_care DESC",
                    new string[] { "Дата", "Растение", "Оранжерея", "Работа", "Сотрудник", "Кол-во", "Статус" });

            case "План работ":
                return new CrudPanel("care", "id_care", new Field[0],
                    "SELECT c.id_care, c.work_date, p.name, w.name, c.quantity, c.comment FROM care c " +
                    "JOIN plant p ON p.id_plant = c.id_plant JOIN work_type w ON w.id_work_type = c.id_work_type " +
                    "WHERE c.result = 'Запланировано' AND c.work_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) ORDER BY c.work_date",
                    new string[] { "Дата (просроченные сверху)", "Растение", "Работа", "Кол-во", "Комментарий" },
                    false, false, false);

            case "Состояние растений":
                return new CrudPanel("plant_condition", "id_plant_condition",
                    new Field[]
                    {
                        Field.Lookup("id_plant", "Растение", QPlant, true),
                        Field.Date("check_date", "Дата проверки", true),
                        Field.Combo("state", "Состояние", new string[] { "Отличное", "Хорошее", "Удовлетворительное", "Плохое" }, true),
                        Field.Text("description", "Описание"),
                        Field.Text("recommendation", "Рекомендации")
                    },
                    "SELECT c.id_plant_condition, p.name, p.variety, c.check_date, c.state, c.description, c.recommendation " +
                    "FROM plant_condition c JOIN plant p ON p.id_plant = c.id_plant ORDER BY c.check_date DESC, c.id_plant_condition DESC",
                    new string[] { "Растение", "Сорт", "Дата", "Состояние", "Описание", "Рекомендации" });

            case "Лечение":
                return new CrudPanel("treatment", "id_treatment",
                    new Field[]
                    {
                        Field.Lookup("id_plant_condition", "Проверка состояния", QCondition, true),
                        Field.Lookup("id_disease", "Заболевание", QDisease, true),
                        Field.Lookup("id_employee", "Сотрудник", QEmployee),
                        Field.Date("treat_date", "Дата лечения", true),
                        Field.Text("action", "Мероприятие"),
                        Field.Text("drug", "Препарат"),
                        Field.Text("result", "Результат"),
                        Field.Date("next_check", "Следующий контроль")
                    },
                    "SELECT t.id_treatment, p.name, d.name, t.treat_date, t.action, t.drug, t.result, t.next_check FROM treatment t " +
                    "JOIN plant_condition pc ON pc.id_plant_condition = t.id_plant_condition JOIN plant p ON p.id_plant = pc.id_plant " +
                    "JOIN disease d ON d.id_disease = t.id_disease ORDER BY t.treat_date DESC, t.id_treatment DESC",
                    new string[] { "Растение", "Заболевание", "Дата", "Мероприятие", "Препарат", "Результат", "След. контроль" });
        }
        throw new ArgumentException("Неизвестный раздел: " + name);
    }
}
