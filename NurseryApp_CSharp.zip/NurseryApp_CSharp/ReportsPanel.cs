using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using MySqlConnector;

namespace Nursery;

/// <summary>Описание одного отчёта.</summary>
public class ReportDef
{
    public string Name;
    public string Sql;
    public string[] Heads;
    public bool Period;   // нужны даты "с" и "по"
    public bool Sum;      // показывать итог по последнему столбцу

    public ReportDef(string name, string sql, string[] heads, bool period, bool sum)
    {
        Name = name; Sql = sql; Heads = heads; Period = period; Sum = sum;
    }
}

/// <summary>Панель формирования отчётов: выбор отчёта, период, фильтр, экспорт в CSV.</summary>
public class ReportsPanel : UserControl
{
    private readonly ReportDef[] defs;
    private readonly ComboBox kind = new ComboBox();
    private readonly DateTimePicker dateFrom = new DateTimePicker();
    private readonly DateTimePicker dateTo = new DateTimePicker();
    private readonly TextBox filter = new TextBox();
    private readonly DataGridView grid = new DataGridView();
    private readonly Label info = new Label();
    private DataTable shown;

    public ReportsPanel(ReportDef[] defs)
    {
        this.defs = defs;
        BackColor = Color.White;

        Theme.StyleGrid(grid);
        grid.Dock = DockStyle.Fill;
        Controls.Add(grid);

        info.Dock = DockStyle.Bottom;
        info.Height = 38;
        info.TextAlign = ContentAlignment.MiddleLeft;
        info.Padding = new Padding(12, 0, 0, 0);
        info.Font = Theme.F(11f, FontStyle.Bold);
        info.ForeColor = Theme.Pink;
        Controls.Add(info);

        Panel bar = new Panel();
        bar.Dock = DockStyle.Top;
        bar.Height = 100;
        bar.BackColor = Color.White;

        kind.Left = 12; kind.Top = 12; kind.Width = 380;
        kind.DropDownStyle = ComboBoxStyle.DropDownList;
        kind.Font = Theme.F(10f);
        foreach (ReportDef d in defs) kind.Items.Add(d.Name);
        kind.SelectedIndex = 0;

        bar.Controls.Add(kind);
        bar.Controls.Add(Lab("с", 410, 16));
        dateFrom.Left = 430; dateFrom.Top = 12; dateFrom.Width = 120; dateFrom.Format = DateTimePickerFormat.Short;
        dateFrom.Value = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        bar.Controls.Add(dateFrom);
        bar.Controls.Add(Lab("по", 562, 16));
        dateTo.Left = 590; dateTo.Top = 12; dateTo.Width = 120; dateTo.Format = DateTimePickerFormat.Short;
        bar.Controls.Add(dateTo);

        bar.Controls.Add(Lab("Фильтр (растение / покупатель):", 12, 62));
        filter.Left = 245; filter.Top = 58; filter.Width = 190; filter.Font = Theme.F(10f);
        bar.Controls.Add(filter);

        Button go = new Button();
        go.Text = "Сформировать";
        go.Left = 452; go.Top = 54; go.Width = 160;
        Theme.StyleButton(go);
        go.Click += (s, e) => Run();
        bar.Controls.Add(go);

        Button exp = new Button();
        exp.Text = "Экспорт в CSV";
        exp.Left = 622; exp.Top = 54; exp.Width = 160;
        Theme.StyleButton(exp, true);
        exp.Click += (s, e) => Export();
        bar.Controls.Add(exp);

        Controls.Add(bar);
        kind.SelectedIndexChanged += (s, e) =>
        {
            bool p = defs[kind.SelectedIndex].Period;
            dateFrom.Enabled = p;
            dateTo.Enabled = p;
        };
        dateFrom.Enabled = defs[0].Period;
        dateTo.Enabled = defs[0].Period;
        Run();
    }

    private static Label Lab(string text, int x, int y)
    {
        Label l = new Label();
        l.Text = text;
        l.Left = x;
        l.Top = y;
        l.AutoSize = true;
        l.ForeColor = Theme.Green;
        l.Font = Theme.F(10f, FontStyle.Bold);
        return l;
    }

    private void Run()
    {
        ReportDef d = defs[kind.SelectedIndex];
        DataTable t;
        try
        {
            t = d.Period ? Db.Table(d.Sql, dateFrom.Value.Date, dateTo.Value.Date) : Db.Table(d.Sql);
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(ex.Message, "Ошибка базы данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        string k = filter.Text.Trim().ToLowerInvariant();
        DataTable view = t.Clone();
        decimal sum = 0;
        foreach (DataRow r in t.Rows)
        {
            if (k.Length > 0)
            {
                bool hit = false;
                foreach (object o in r.ItemArray)
                {
                    if (Convert.ToString(o).ToLowerInvariant().Contains(k)) { hit = true; break; }
                }
                if (!hit) continue;
            }
            view.ImportRow(r);
            if (d.Sum && t.Columns.Count > 0)
            {
                object last = r[t.Columns.Count - 1];
                if (last != null && !(last is DBNull)) sum += Convert.ToDecimal(last);
            }
        }

        shown = view;
        grid.DataSource = view;
        for (int i = 0; i < d.Heads.Length && i < grid.Columns.Count; i++)
            grid.Columns[i].HeaderText = d.Heads[i];
        Theme.FormatColumns(grid);
        info.Text = "Строк: " + view.Rows.Count + (d.Sum ? "     Итого: " + sum.ToString("N2") + " ₽" : "");
    }

    private void Export()
    {
        if (shown == null) return;
        using (SaveFileDialog dlg = new SaveFileDialog())
        {
            dlg.Filter = "CSV (*.csv)|*.csv";
            dlg.FileName = defs[kind.SelectedIndex].Name + ".csv";
            if (dlg.ShowDialog(FindForm()) != DialogResult.OK) return;
            StringBuilder sb = new StringBuilder();
            List<string> head = new List<string>();
            foreach (DataGridViewColumn c in grid.Columns) head.Add(Quote(c.HeaderText));
            sb.AppendLine(string.Join(";", head));
            foreach (DataRow r in shown.Rows)
            {
                List<string> cells = new List<string>();
                foreach (object o in r.ItemArray)
                {
                    string s = o is DateTime ? ((DateTime)o).ToString("dd.MM.yyyy") : Convert.ToString(o);
                    cells.Add(Quote(s));
                }
                sb.AppendLine(string.Join(";", cells));
            }
            File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
            MessageBox.Show("Отчёт сохранён в файл:\n" + dlg.FileName, "Экспорт", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private static string Quote(string s)
    {
        return "\"" + (s ?? "").Replace("\"", "\"\"") + "\"";
    }
}
