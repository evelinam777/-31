АИС «Питомник растений» (C#, .NET 8, WinForms, MySQL)

Что нужно:
1. XAMPP: в XAMPP Control Panel нажать Start напротив MySQL.
2. .NET 8 SDK (dotnet.microsoft.com), проверка: в терминале dotnet --version

Запуск (в папке с NurseryApp.csproj):
   dotnet restore
   dotnet run

При первом запуске программа сама создаёт базу nursery из schema.sql
(таблицы, триггеры, тестовые данные).

Логины: manager / manager123, agronom / agro123, admin / admin123

Внимание: код написан, но в среде разработки не компилировался.
Если dotnet run выдаёт ошибку, пришлите её текст.

Папка docs: er.dot (исходник ER-диаграммы для Graphviz), img/er.png, schema_ddl.sql (скрипт БД без данных).
