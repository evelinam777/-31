using System.Drawing;
using System.Windows.Forms;

namespace Nursery;

/// <summary>Цветовая схема (розовый, зелёный, белый) и общее оформление элементов.</summary>
public static class Theme
{
    public static readonly Color Pink = ColorTranslator.FromHtml("#E91E8C");
    public static readonly Color PinkLight = ColorTranslator.FromHtml("#FCE4EF");
    public static readonly Color PinkDark = ColorTranslator.FromHtml("#AD1457");
    public static readonly Color Green = ColorTranslator.FromHtml("#2E7D32");
    public static readonly Color GreenLight = ColorTranslator.FromHtml("#E8F5E9");

    public static Font F(float size, FontStyle style = FontStyle.Regular)
    {
        return new Font("Segoe UI", size, style);
    }

    /// <summary>Плоская кнопка: зелёная (или розовая), при наведении цвета меняются местами.</summary>
    public static void StyleButton(Button b, bool pink = false)
    {
        Color normal = pink ? Pink : Green;
        Color hover = pink ? Green : Pink;
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.UseVisualStyleBackColor = false;
        b.BackColor = normal;
        b.ForeColor = Color.White;
        b.Font = F(10f, FontStyle.Bold);
        b.Cursor = Cursors.Hand;
        b.Height = 34;
        b.MouseEnter += (s, e) => b.BackColor = hover;
        b.MouseLeave += (s, e) => b.BackColor = normal;
    }

    /// <summary>Единый вид таблиц: зелёная шапка, зелёные полосы, розовое выделение.</summary>
    public static void StyleGrid(DataGridView g)
    {
        g.BackgroundColor = Color.White;
        g.BorderStyle = BorderStyle.None;
        g.EnableHeadersVisualStyles = false;
        g.ColumnHeadersDefaultCellStyle.BackColor = Green;
        g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Green;
        g.ColumnHeadersDefaultCellStyle.Font = F(10f, FontStyle.Bold);
        g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        g.ColumnHeadersHeight = 34;
        g.RowHeadersVisible = false;
        g.AllowUserToAddRows = false;
        g.AllowUserToDeleteRows = false;
        g.AllowUserToResizeRows = false;
        g.ReadOnly = true;
        g.MultiSelect = false;
        g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        g.RowTemplate.Height = 28;
        g.DefaultCellStyle.Font = F(10f);
        g.DefaultCellStyle.SelectionBackColor = Pink;
        g.DefaultCellStyle.SelectionForeColor = Color.White;
        g.AlternatingRowsDefaultCellStyle.BackColor = GreenLight;
        g.GridColor = PinkLight;
        g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
    }

    /// <summary>Применить форматы: даты dd.MM.yyyy, числа без лишних нулей.</summary>
    public static void FormatColumns(DataGridView g)
    {
        foreach (DataGridViewColumn c in g.Columns)
        {
            if (c.ValueType == typeof(DateTime)) c.DefaultCellStyle.Format = "dd.MM.yyyy";
            else if (c.ValueType == typeof(decimal)) c.DefaultCellStyle.Format = "0.##";
        }
    }
}
