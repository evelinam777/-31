using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MySqlConnector;

namespace Nursery;

/// <summary>
/// Оформление документа: продажа (isSale = true) или поступление от поставщика (isSale = false).
/// Остатки растений изменяются автоматически в одной транзакции.
/// </summary>
public class DocForm : Form
{
    private class Item
    {
        public int Id;
        public string Name;
        public int Qty;
        public decimal Price;
        public decimal Disc;
        public decimal Total;
    }

    private readonly bool isSale;
    private readonly Action done;
    private readonly List<Item> items = new List<Item>();

    private readonly ComboBox partner = new ComboBox();
    private readonly DateTimePicker date = new DateTimePicker();
    private readonly TextBox num = new TextBox();
    private readonly ComboBox extra = new ComboBox();
    private readonly ComboBox plant = new ComboBox();
    private readonly TextBox qty = new TextBox();
    private readonly TextBox price = new TextBox();
    private readonly TextBox disc = new TextBox();
    private readonly DataGridView grid = new DataGridView();
    private readonly Label total = new Label();

    public DocForm(bool isSale, Action done)
    {
        this.isSale = isSale;
        this.done = done;

        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        Text = isSale ? "Оформление продажи" : "Оформление поставки";
        Font = Theme.F(10f);
        BackColor = Color.White;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(920, 604);

        // --- Шапка документа ---
        AddLabel(isSale ? "Покупатель (выберите или введите ФИО)" : "Поставщик", 16, 14);
        partner.Left = 16; partner.Top = 38; partner.Width = 360;
        partner.DropDownStyle = isSale ? ComboBoxStyle.DropDown : ComboBoxStyle.DropDownList;
        partner.Items.AddRange(Db.Lookup(isSale
            ? "SELECT id_customer, name FROM customer ORDER BY name"
            : "SELECT id_supplier, name FROM supplier ORDER BY name").ToArray());
        if (!isSale && partner.Items.Count > 0) partner.SelectedIndex = 0;
        Controls.Add(partner);

        AddLabel("Дата", 392, 14);
        date.Left = 392; date.Top = 38; date.Width = 140; date.Format = DateTimePickerFormat.Short;
        Controls.Add(date);

        AddLabel("№ документа", 548, 14);
        num.Left = 548; num.Top = 38; num.Width = 170;
        num.Text = (isSale ? "ПР-" : "ПС-") + DateTime.Now.ToString("yyMMddHHmm");
        Controls.Add(num);

        AddLabel(isSale ? "Способ оплаты" : "Оранжерея (куда поступили)", 734, 14);
        extra.Left = 734; extra.Top = 38; extra.Width = 170;
        extra.DropDownStyle = ComboBoxStyle.DropDownList;
        if (isSale)
            extra.Items.AddRange(new object[] { "Наличные", "Карта", "Перевод" });
        else
            extra.Items.AddRange(Db.Lookup("SELECT id_greenhouse, CONCAT('№', number, ' (', COALESCE(type, ''), ')') FROM greenhouse ORDER BY number").ToArray());
        if (extra.Items.Count > 0) extra.SelectedIndex = 0;
        Controls.Add(extra);

        // --- Добавление позиции ---
        AddLabel("Растение", 16, 84);
        plant.Left = 16; plant.Top = 108; plant.Width = 360;
        plant.DropDownStyle = ComboBoxStyle.DropDownList;
        plant.Items.AddRange(Db.Lookup(
            "SELECT id_plant, CONCAT(name, CASE WHEN variety IS NULL OR variety = '' THEN '' ELSE CONCAT(' «', variety, '»') END) FROM plant ORDER BY name").ToArray());
        plant.SelectedIndexChanged += (s, e) => OnPlantPicked();
        Controls.Add(plant);

        AddLabel("Кол-во", 392, 84);
        qty.Left = 392; qty.Top = 108; qty.Width = 80;
        Controls.Add(qty);

        AddLabel("Цена, ₽", 488, 84);
        price.Left = 488; price.Top = 108; price.Width = 110;
        Controls.Add(price);

        AddLabel("Скидка, %", 614, 84);
        disc.Left = 614; disc.Top = 108; disc.Width = 90;
        disc.Text = "0";
        disc.Enabled = isSale;
        Controls.Add(disc);

        Button add = new Button();
        add.Text = "+ В список";
        add.Left = 720; add.Top = 106; add.Width = 184;
        Theme.StyleButton(add);
        add.Click += (s, e) => AddItem();
        Controls.Add(add);

        // --- Таблица позиций ---
        Theme.StyleGrid(grid);
        grid.Left = 16; grid.Top = 156; grid.Width = 888; grid.Height = 380;
        grid.BorderStyle = BorderStyle.FixedSingle;
        Controls.Add(grid);

        // --- Итог и кнопки ---
        total.Left = 16; total.Top = 552; total.Width = 380; total.Height = 34;
        total.Font = Theme.F(14f, FontStyle.Bold);
        total.ForeColor = Theme.Pink;
        total.Text = "Итого: 0,00 ₽";
        Controls.Add(total);

        Button remove = new Button();
        remove.Text = "Убрать позицию";
        remove.Left = 404; remove.Top = 548; remove.Width = 160;
        Theme.StyleButton(remove);
        remove.Click += (s, e) => RemoveItem();
        Controls.Add(remove);

        Button ok = new Button();
        ok.Text = "Провести";
        ok.Left = 574; ok.Top = 548; ok.Width = 160;
        Theme.StyleButton(ok);
        ok.Click += (s, e) => OnSave();
        Controls.Add(ok);

        Button cancel = new Button();
        cancel.Text = "Отмена";
        cancel.Left = 744; cancel.Top = 548; cancel.Width = 160;
        Theme.StyleButton(cancel, true);
        cancel.DialogResult = DialogResult.Cancel;
        Controls.Add(cancel);
        CancelButton = cancel;

        RefreshGrid();
    }

    private void AddLabel(string text, int x, int y)
    {
        Label l = new Label();
        l.Text = text;
        l.Left = x;
        l.Top = y;
        l.AutoSize = true;
        l.ForeColor = Theme.Green;
        Controls.Add(l);
    }

    private void OnPlantPicked()
    {
        ComboItem it = plant.SelectedItem as ComboItem;
        if (it == null || !isSale) return;
        object p = Db.Scalar("SELECT price FROM plant WHERE id_plant = @p0", it.Id);
        if (p != null) price.Text = Convert.ToDecimal(p).ToString("0.##");
    }

    private static bool TryDecimal(string s, out decimal v)
    {
        return decimal.TryParse(s.Trim().Replace('.', ','), System.Globalization.NumberStyles.Number,
            new System.Globalization.CultureInfo("ru-RU"), out v);
    }

    private void AddItem()
    {
        ComboItem it = plant.SelectedItem as ComboItem;
        int q;
        decimal pr, d;
        if (it == null || !int.TryParse(qty.Text.Trim(), out q) || q <= 0 ||
            !TryDecimal(price.Text, out pr) || pr < 0 ||
            !TryDecimal(isSale ? disc.Text : "0", out d) || d < 0 || d > 100)
        {
            MessageBox.Show("Выберите растение и укажите корректные количество, цену и скидку (0-100).",
                "Проверка данных", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (isSale)
        {
            int have = Convert.ToInt32(Db.Scalar("SELECT COALESCE(SUM(quantity), 0) FROM stock WHERE id_plant = @p0", it.Id));
            int used = 0;
            foreach (Item x in items) if (x.Id == it.Id) used += x.Qty;
            if (q + used > have)
            {
                MessageBox.Show("Недостаточно растений на складе.\nВ наличии: " + have + ", уже в списке: " + used,
                    "Нет нужного количества", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        Item item = new Item();
        item.Id = it.Id;
        item.Name = it.Text;
        item.Qty = q;
        item.Price = pr;
        item.Disc = d;
        item.Total = Math.Round(q * pr * (1m - d / 100m), 2);
        items.Add(item);
        qty.Text = "";
        RefreshGrid();
    }

    private void RemoveItem()
    {
        if (grid.SelectedRows.Count == 0) return;
        int idx = grid.SelectedRows[0].Index;
        if (idx >= 0 && idx < items.Count)
        {
            items.RemoveAt(idx);
            RefreshGrid();
        }
    }

    private void RefreshGrid()
    {
        DataTable t = new DataTable();
        t.Columns.Add("Растение", typeof(string));
        t.Columns.Add("Кол-во", typeof(int));
        t.Columns.Add("Цена", typeof(decimal));
        t.Columns.Add("Скидка %", typeof(decimal));
        t.Columns.Add("Сумма", typeof(decimal));
        decimal sum = 0;
        foreach (Item x in items)
        {
            t.Rows.Add(x.Name, x.Qty, x.Price, x.Disc, x.Total);
            sum += x.Total;
        }
        grid.DataSource = t;
        Theme.FormatColumns(grid);
        total.Text = "Итого: " + sum.ToString("N2") + " ₽";
    }

    private void OnSave()
    {
        if (items.Count == 0)
        {
            MessageBox.Show("Добавьте в список хотя бы одну позицию.", "Проверка данных", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (partner.Text.Trim().Length == 0 || extra.SelectedItem == null)
        {
            MessageBox.Show("Заполните шапку документа.", "Проверка данных", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        string msg;
        try
        {
            msg = isSale ? SaveSale() : SaveReceipt();
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(ex.Message, "Ошибка базы данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        MessageBox.Show(msg, "Документ проведён", MessageBoxButtons.OK, MessageBoxIcon.Information);
        done();
        DialogResult = DialogResult.OK;
    }

    /// <summary>Сохранение поставки: документ, позиции и увеличение остатков (одна транзакция).</summary>
    private string SaveReceipt()
    {
        ComboItem sup = (ComboItem)partner.SelectedItem;
        ComboItem gh = (ComboItem)extra.SelectedItem;
        using (MySqlConnection c = Db.Open())
        using (MySqlTransaction tx = c.BeginTransaction())
        {
            try
            {
                MySqlCommand head = Db.Cmd(c, tx,
                    "INSERT INTO receipt (id_supplier, receipt_date, doc_number) VALUES (@p0, @p1, @p2)",
                    sup.Id, date.Value.Date, num.Text.Trim());
                head.ExecuteNonQuery();
                long rid = head.LastInsertedId;
                foreach (Item it in items)
                {
                    Db.Cmd(c, tx,
                        "INSERT INTO receipt_item (id_receipt, id_plant, quantity, purchase_price) VALUES (@p0, @p1, @p2, @p3)",
                        rid, it.Id, it.Qty, it.Price).ExecuteNonQuery();
                    // Если растение уже есть в этой оранжерее — увеличиваем количество, иначе создаём строку остатка
                    Db.Cmd(c, tx,
                        "INSERT INTO stock (id_plant, id_greenhouse, quantity) VALUES (@p0, @p1, @p2) " +
                        "ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)",
                        it.Id, gh.Id, it.Qty).ExecuteNonQuery();
                }
                tx.Commit();
            }
            catch (Exception)
            {
                tx.Rollback();
                throw;
            }
        }
        return "Поставка сохранена, остатки растений увеличены.";
    }

    /// <summary>Сохранение продажи: документ, позиции и списание остатков (одна транзакция).</summary>
    private string SaveSale()
    {
        StringBuilder sb = new StringBuilder();
        using (MySqlConnection c = Db.Open())
        using (MySqlTransaction tx = c.BeginTransaction())
        {
            try
            {
                // Покупатель: выбран из списка или введён новым ФИО
                ComboItem sel = partner.SelectedItem as ComboItem;
                string typed = partner.Text.Trim();
                int cid;
                if (sel != null && sel.Text == typed)
                {
                    cid = sel.Id;
                }
                else
                {
                    object found = Db.Cmd(c, tx, "SELECT id_customer FROM customer WHERE name = @p0 LIMIT 1", typed).ExecuteScalar();
                    if (found != null && !(found is DBNull))
                    {
                        cid = Convert.ToInt32(found);
                    }
                    else
                    {
                        MySqlCommand nc = Db.Cmd(c, tx, "INSERT INTO customer (name) VALUES (@p0)", typed);
                        nc.ExecuteNonQuery();
                        cid = (int)nc.LastInsertedId;
                    }
                }

                MySqlCommand head = Db.Cmd(c, tx,
                    "INSERT INTO sale (id_customer, sale_date, doc_number, payment) VALUES (@p0, @p1, @p2, @p3)",
                    cid, date.Value.Date, num.Text.Trim(), extra.SelectedItem.ToString());
                head.ExecuteNonQuery();
                long saleId = head.LastInsertedId;

                foreach (Item it in items)
                {
                    int before = Convert.ToInt32(Db.Cmd(c, tx,
                        "SELECT COALESCE(SUM(quantity), 0) FROM stock WHERE id_plant = @p0", it.Id).ExecuteScalar());

                    // Триггер trg_sale_item_bi проверит наличие и пересчитает сумму строки
                    Db.Cmd(c, tx,
                        "INSERT INTO sale_item (id_sale, id_plant, quantity, price, discount, total) VALUES (@p0, @p1, @p2, @p3, @p4, @p5)",
                        saleId, it.Id, it.Qty, it.Price, it.Disc, it.Total).ExecuteNonQuery();

                    // Списание остатка: сначала из оранжереи, где растений больше всего
                    List<int> stockIds = new List<int>();
                    List<int> stockQty = new List<int>();
                    using (MySqlDataReader r = Db.Cmd(c, tx,
                        "SELECT id_stock, quantity FROM stock WHERE id_plant = @p0 AND quantity > 0 ORDER BY quantity DESC", it.Id).ExecuteReader())
                    {
                        while (r.Read())
                        {
                            stockIds.Add(r.GetInt32(0));
                            stockQty.Add(r.GetInt32(1));
                        }
                    }
                    int need = it.Qty;
                    for (int i = 0; i < stockIds.Count && need > 0; i++)
                    {
                        int take = Math.Min(stockQty[i], need);
                        Db.Cmd(c, tx, "UPDATE stock SET quantity = quantity - @p0 WHERE id_stock = @p1", take, stockIds[i]).ExecuteNonQuery();
                        need -= take;
                    }
                    sb.AppendLine(it.Name + ": было " + before + ", продано " + it.Qty + ", осталось " + (before - it.Qty));
                }
                tx.Commit();
            }
            catch (Exception)
            {
                tx.Rollback();
                throw;
            }
        }
        decimal sum = 0;
        foreach (Item it in items) sum += it.Total;
        sb.AppendLine();
        sb.AppendLine("Сумма продажи: " + sum.ToString("N2") + " ₽");
        return sb.ToString();
    }
}
