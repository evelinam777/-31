using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Nursery;

/// <summary>Главная страница: плитки статистики и витрина растений с иллюстрациями.</summary>
public class HomePanel : UserControl
{
    private readonly string userName;

    public HomePanel(string userName)
    {
        this.userName = userName;
        BackColor = Color.White;
        Build();
    }

    private void Build()
    {
        DateTime monthStart = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        int kinds = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM plant"));
        int total = Convert.ToInt32(Db.Scalar("SELECT COALESCE(SUM(quantity), 0) FROM stock"));
        int low = Convert.ToInt32(Db.Scalar(
            "SELECT COUNT(*) FROM (SELECT COALESCE(SUM(s.quantity), 0) AS q, p.min_stock AS m " +
            "FROM plant p LEFT JOIN stock s ON s.id_plant = p.id_plant GROUP BY p.id_plant, p.min_stock) t WHERE t.q <= t.m"));
        decimal revenue = Convert.ToDecimal(Db.Scalar(
            "SELECT COALESCE(SUM(si.total), 0) FROM sale s JOIN sale_item si ON si.id_sale = s.id_sale WHERE s.sale_date >= @p0", monthStart));

        // Витрина растений (добавляется первой, потому что занимает всё свободное место)
        FlowLayoutPanel showcase = new FlowLayoutPanel();
        showcase.Dock = DockStyle.Fill;
        showcase.AutoScroll = true;
        showcase.Padding = new Padding(10, 4, 10, 10);
        showcase.BackColor = Color.White;
        Controls.Add(showcase);

        DataTable t = Db.Table(
            "SELECT p.name, p.variety, p.category, p.price, p.photo, COALESCE(SUM(st.quantity), 0), p.min_stock " +
            "FROM plant p LEFT JOIN stock st ON st.id_plant = p.id_plant " +
            "GROUP BY p.id_plant, p.name, p.variety, p.category, p.price, p.photo, p.min_stock ORDER BY p.name LIMIT 8");
        foreach (DataRow r in t.Rows)
            showcase.Controls.Add(MakeCard(r));

        Label head = new Label();
        head.Text = "Витрина питомника";
        head.Dock = DockStyle.Top;
        head.Height = 38;
        head.Padding = new Padding(16, 6, 0, 0);
        head.Font = Theme.F(14f, FontStyle.Bold);
        head.ForeColor = Theme.Green;
        Controls.Add(head);

        TableLayoutPanel tiles = new TableLayoutPanel();
        tiles.Dock = DockStyle.Top;
        tiles.Height = 96;
        tiles.ColumnCount = 4;
        tiles.RowCount = 1;
        tiles.Padding = new Padding(8, 4, 8, 4);
        for (int i = 0; i < 4; i++) tiles.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
        tiles.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
        tiles.Controls.Add(MakeTile("icon_plants.png", kinds.ToString(), "Видов растений", Theme.Pink), 0, 0);
        tiles.Controls.Add(MakeTile("icon_box.png", total.ToString(), "Всего на складе, шт", Theme.Green), 1, 0);
        tiles.Controls.Add(MakeTile("icon_alert.png", low.ToString(), "Низкий остаток", low > 0 ? Theme.PinkDark : Theme.Green), 2, 0);
        tiles.Controls.Add(MakeTile("icon_money.png", revenue.ToString("N0"), "Выручка за месяц, ₽", Theme.Green), 3, 0);
        Controls.Add(tiles);

        Label title = new Label();
        title.Text = "Добро пожаловать, " + userName + "!";
        title.Dock = DockStyle.Top;
        title.Height = 50;
        title.Padding = new Padding(16, 10, 0, 0);
        title.Font = Theme.F(17f, FontStyle.Bold);
        title.ForeColor = Theme.PinkDark;
        Controls.Add(title);
    }

    private Control MakeTile(string icon, string value, string caption, Color color)
    {
        Panel p = new Panel();
        p.Dock = DockStyle.Fill;
        p.BackColor = color;
        p.Margin = new Padding(6);

        PictureBox pic = new PictureBox();
        pic.Image = Assets.Named(icon, 48, 48);
        pic.SizeMode = PictureBoxSizeMode.CenterImage;
        pic.BackColor = color;
        pic.Left = 10; pic.Top = 14; pic.Width = 60; pic.Height = 56;
        p.Controls.Add(pic);

        Label v = new Label();
        v.Text = value;
        v.ForeColor = Color.White;
        v.BackColor = color;
        v.Font = Theme.F(20f, FontStyle.Bold);
        v.AutoSize = true;
        v.Left = 76; v.Top = 8;
        p.Controls.Add(v);

        Label c = new Label();
        c.Text = caption;
        c.ForeColor = Color.White;
        c.BackColor = color;
        c.Font = Theme.F(9f);
        c.AutoSize = true;
        c.Left = 78; v.Top = 8; c.Top = 52;
        p.Controls.Add(c);
        return p;
    }

    private Control MakeCard(DataRow r)
    {
        string name = Convert.ToString(r[0]);
        string variety = Convert.ToString(r[1]);
        string category = Convert.ToString(r[2]);
        decimal price = Convert.ToDecimal(r[3]);
        string photo = Convert.ToString(r[4]);
        int qty = Convert.ToInt32(r[5]);
        int min = Convert.ToInt32(r[6]);
        bool low = qty <= min;
        Color border = low ? Theme.Pink : Theme.Green;

        Panel card = new Panel();
        card.Width = 200;
        card.Height = 250;
        card.Margin = new Padding(8);
        card.BackColor = Color.White;
        card.Paint += (s, e) =>
        {
            using (Pen pen = new Pen(border, 3))
                e.Graphics.DrawRectangle(pen, 1, 1, card.Width - 3, card.Height - 3);
        };

        PictureBox pic = new PictureBox();
        pic.Image = Assets.PlantImage(name, category, photo, 130, 130);
        pic.SizeMode = PictureBoxSizeMode.CenterImage;
        pic.Left = 10; pic.Top = 8; pic.Width = 180; pic.Height = 136;
        card.Controls.Add(pic);

        Label n = new Label();
        n.Text = name;
        n.Font = Theme.F(11f, FontStyle.Bold);
        n.ForeColor = Theme.PinkDark;
        n.TextAlign = ContentAlignment.MiddleCenter;
        n.Left = 6; n.Top = 146; n.Width = 188; n.Height = 24;
        card.Controls.Add(n);

        Label v = new Label();
        v.Text = string.IsNullOrEmpty(variety) ? category : variety;
        v.Font = Theme.F(9f);
        v.ForeColor = Color.Gray;
        v.TextAlign = ContentAlignment.MiddleCenter;
        v.Left = 6; v.Top = 170; v.Width = 188; v.Height = 20;
        card.Controls.Add(v);

        Label pr = new Label();
        pr.Text = price.ToString("0.##") + " ₽   ·   " + qty + " шт";
        pr.Font = Theme.F(10f, FontStyle.Bold);
        pr.ForeColor = low ? Theme.PinkDark : Theme.Green;
        pr.BackColor = low ? Theme.PinkLight : Theme.GreenLight;
        pr.TextAlign = ContentAlignment.MiddleCenter;
        pr.Left = 8; pr.Top = 208; pr.Width = 184; pr.Height = 34;
        card.Controls.Add(pr);
        return card;
    }
}
