using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySqlConnector;

namespace Nursery;

/// <summary>
/// Универсальная таблица данных: поиск, добавление, изменение, удаление.
/// Первый столбец запроса — идентификатор (скрыт); далее столбцы по числу заголовков;
/// необязательный последний столбец со значением "low" подсвечивает строку розовым.
/// </summary>
public class CrudPanel : UserControl
{
    private readonly string table;
    private readonly string pk;
    private readonly string sql;
    private readonly Field[] fields;
    private readonly string[] heads;
    private readonly bool canEdit;
    private readonly TextBox search = new TextBox();
    private readonly Label count = new Label();
    private DataTable all;

    public readonly DataGridView Grid = new DataGridView();
    public Func<int, string> Details;          // подробности по двойному клику
    public Action<Action> AddOverride;         // своё окно вместо стандартной формы добавления

    public CrudPanel(string table, string pk, Field[] fields, string sql, string[] heads,
                     bool add = true, bool edit = true, bool delete = true)
    {
        this.table = table;
        this.pk = pk;
        this.fields = fields;
        this.sql = sql;
        this.heads = heads;
        this.canEdit = edit;
        BackColor = Color.White;

        Theme.StyleGrid(Grid);
        Grid.Dock = DockStyle.Fill;
        Controls.Add(Grid);

        Panel bar = new Panel();
        bar.Dock = DockStyle.Top;
        bar.Height = 54;
        bar.BackColor = Color.White;

        Label lblSearch = new Label();
        lblSearch.Text = "Поиск:";
        lblSearch.Left = 12;
        lblSearch.Top = 17;
        lblSearch.AutoSize = true;
        lblSearch.Font = Theme.F(10f, FontStyle.Bold);
        lblSearch.ForeColor = Theme.Green;

        search.Left = 75;
        search.Top = 13;
        search.Width = 240;
        search.Font = Theme.F(10f);

        count.Left = 330;
        count.Top = 17;
        count.AutoSize = true;
        count.ForeColor = Theme.Green;
        count.Font = Theme.F(10f);

        FlowLayoutPanel btns = new FlowLayoutPanel();
        btns.Dock = DockStyle.Right;
        btns.AutoSize = true;
        btns.WrapContents = false;
        btns.Padding = new Padding(0, 8, 8, 0);
        btns.BackColor = Color.White;
        if (add) btns.Controls.Add(MakeButton("+ Добавить", false, (s, e) => OnAdd()));
        if (edit) btns.Controls.Add(MakeButton("Изменить", false, (s, e) => OnEdit()));
        if (delete) btns.Controls.Add(MakeButton("Удалить", true, (s, e) => OnDelete()));

        bar.Controls.Add(btns);
        bar.Controls.Add(lblSearch);
        bar.Controls.Add(search);
        bar.Controls.Add(count);
        Controls.Add(bar);

        search.TextChanged += (s, e) => { if (all != null) Apply(); };
        Grid.CellDoubleClick += OnCellDoubleClick;
        Reload();
    }

    private Button MakeButton(string text, bool pink, EventHandler handler)
    {
        Button b = new Button();
        b.Text = text;
        b.Width = 125;
        Theme.StyleButton(b, pink);
        b.Click += handler;
        return b;
    }

    /// <summary>Перечитать данные из базы.</summary>
    public void Reload()
    {
        all = Db.Table(sql);
        Apply();
    }

    private void Apply()
    {
        string k = search.Text.Trim().ToLowerInvariant();
        int n = heads.Length;
        DataTable view = all.Clone();
        foreach (DataRow r in all.Rows)
        {
            if (k.Length > 0)
            {
                bool hit = false;
                for (int i = 1; i <= n && i < all.Columns.Count; i++)
                {
                    if (Convert.ToString(r[i]).ToLowerInvariant().Contains(k)) { hit = true; break; }
                }
                if (!hit) continue;
            }
            view.ImportRow(r);
        }

        Grid.DataSource = view;
        Grid.CurrentCell = null;
        Grid.ClearSelection();
        if (Grid.Columns.Count > 0) Grid.Columns[0].Visible = false;
        for (int i = 1; i <= n && i < Grid.Columns.Count; i++)
            Grid.Columns[i].HeaderText = heads[i - 1];
        Theme.FormatColumns(Grid);

        int marker = n + 1;
        if (Grid.Columns.Count > marker)
        {
            Grid.Columns[marker].Visible = false;
            foreach (DataGridViewRow row in Grid.Rows)
            {
                if (Convert.ToString(row.Cells[marker].Value) == "low")
                {
                    row.DefaultCellStyle.BackColor = Theme.PinkLight;
                    row.DefaultCellStyle.ForeColor = Theme.PinkDark;
                }
            }
        }
        count.Text = "Записей: " + view.Rows.Count;
    }

    /// <summary>Идентификатор выбранной строки или -1, если ничего не выбрано.</summary>
    public int SelectedId()
    {
        if (Grid.SelectedRows.Count == 0) return -1;
        return Convert.ToInt32(Grid.SelectedRows[0].Cells[0].Value);
    }

    private int NeedSelection()
    {
        int id = SelectedId();
        if (id < 0)
            MessageBox.Show("Выберите запись в таблице.", "Выбор записи", MessageBoxButtons.OK, MessageBoxIcon.Information);
        return id;
    }

    private void OnAdd()
    {
        if (AddOverride != null)
        {
            AddOverride(Reload);
            return;
        }
        using (EditForm f = new EditForm("Добавить запись", fields, null, Insert))
        {
            if (f.ShowDialog(FindForm()) == DialogResult.OK) Reload();
        }
    }

    private void Insert(Dictionary<string, object> d)
    {
        List<string> cols = new List<string>(d.Keys);
        List<string> ps = new List<string>();
        List<object> vals = new List<object>();
        for (int i = 0; i < cols.Count; i++)
        {
            ps.Add("@p" + i);
            vals.Add(d[cols[i]]);
        }
        string q = "INSERT INTO " + table + " (" + string.Join(", ", cols) + ") VALUES (" + string.Join(", ", ps) + ")";
        Db.Exec(q, vals.ToArray());
    }

    private void OnEdit()
    {
        int id = NeedSelection();
        if (id < 0) return;
        List<string> cols = new List<string>();
        foreach (Field f in fields) cols.Add(f.Col);
        DataTable t = Db.Table("SELECT " + string.Join(", ", cols) + " FROM " + table + " WHERE " + pk + " = @p0", id);
        if (t.Rows.Count == 0) { Reload(); return; }
        using (EditForm f = new EditForm("Изменить запись", fields, t.Rows[0], d => Update(id, d)))
        {
            if (f.ShowDialog(FindForm()) == DialogResult.OK) Reload();
        }
    }

    private void Update(int id, Dictionary<string, object> d)
    {
        List<string> sets = new List<string>();
        List<object> vals = new List<object>();
        int i = 0;
        foreach (KeyValuePair<string, object> kv in d)
        {
            sets.Add(kv.Key + " = @p" + i);
            vals.Add(kv.Value);
            i++;
        }
        vals.Add(id);
        string q = "UPDATE " + table + " SET " + string.Join(", ", sets) + " WHERE " + pk + " = @p" + i;
        Db.Exec(q, vals.ToArray());
    }

    private void OnDelete()
    {
        int id = NeedSelection();
        if (id < 0) return;
        if (MessageBox.Show("Удалить выбранную запись?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            return;
        try
        {
            Db.Exec("DELETE FROM " + table + " WHERE " + pk + " = @p0", id);
        }
        catch (MySqlException ex)
        {
            if (ex.Number == 1451 || ex.Number == 1217)
                MessageBox.Show("Запись используется в других таблицах, удаление невозможно.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
                MessageBox.Show(ex.Message, "Ошибка базы данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        Reload();
    }

    private void OnCellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0) return;
        int id = Convert.ToInt32(Grid.Rows[e.RowIndex].Cells[0].Value);
        if (Details != null)
            MessageBox.Show(Details(id), "Подробности", MessageBoxButtons.OK, MessageBoxIcon.Information);
        else if (canEdit)
            OnEdit();
    }
}
