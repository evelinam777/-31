using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Nursery;

/// <summary>Окно входа по логину и паролю.</summary>
public class LoginForm : Form
{
    public string FullName;
    public string Role;

    private readonly TextBox txtLogin = new TextBox();
    private readonly TextBox txtPass = new TextBox();

    public LoginForm()
    {
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        Text = "Вход в систему";
        Font = Theme.F(10f);
        BackColor = Color.White;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(760, 420);

        PictureBox hero = new PictureBox();
        hero.Left = 0; hero.Top = 0; hero.Width = 360; hero.Height = 420;
        hero.Image = Assets.Named("hero.png", 360, 420);
        hero.SizeMode = PictureBoxSizeMode.CenterImage;
        hero.BackColor = Theme.PinkLight;
        Controls.Add(hero);

        Label title = new Label();
        title.Text = "Питомник растений";
        title.Left = 360; title.Top = 0; title.Width = 400; title.Height = 70;
        title.BackColor = Theme.Pink;
        title.ForeColor = Color.White;
        title.Font = Theme.F(19f, FontStyle.Bold);
        title.TextAlign = ContentAlignment.MiddleCenter;
        Controls.Add(title);

        Panel strip = new Panel();
        strip.Left = 360; strip.Top = 70; strip.Width = 400; strip.Height = 4;
        strip.BackColor = Theme.Green;
        Controls.Add(strip);

        Label welcome = new Label();
        welcome.Text = "Добро пожаловать!\nВойдите в систему";
        welcome.Left = 390; welcome.Top = 92; welcome.Width = 340; welcome.Height = 52;
        welcome.Font = Theme.F(12f, FontStyle.Bold);
        welcome.ForeColor = Theme.Green;
        Controls.Add(welcome);

        AddLabel("Логин", 150);
        txtLogin.Left = 390; txtLogin.Top = 174; txtLogin.Width = 340;
        txtLogin.Font = Theme.F(11f);
        Controls.Add(txtLogin);

        AddLabel("Пароль", 214);
        txtPass.Left = 390; txtPass.Top = 238; txtPass.Width = 340;
        txtPass.Font = Theme.F(11f);
        txtPass.UseSystemPasswordChar = true;
        Controls.Add(txtPass);

        Button go = new Button();
        go.Text = "Войти";
        go.Left = 390; go.Top = 290; go.Width = 340; go.Height = 40;
        Theme.StyleButton(go);
        go.Height = 40;
        go.Click += (s, e) => OnLogin();
        Controls.Add(go);
        AcceptButton = go;

        Label hint = new Label();
        hint.Text = "Тестовые учётные записи:\nmanager / manager123,  agronom / agro123,  admin / admin123";
        hint.Left = 390; hint.Top = 346; hint.Width = 350; hint.Height = 50;
        hint.Font = Theme.F(8.5f);
        hint.ForeColor = Theme.Green;
        Controls.Add(hint);
    }

    private void AddLabel(string text, int top)
    {
        Label l = new Label();
        l.Text = text;
        l.Left = 390;
        l.Top = top + 0;
        l.AutoSize = true;
        l.ForeColor = Theme.Green;
        Controls.Add(l);
    }

    private void OnLogin()
    {
        DataTable t;
        try
        {
            t = Db.Table("SELECT full_name, role FROM app_user WHERE login = @p0 AND password_hash = @p1",
                txtLogin.Text.Trim(), Db.Hash(txtPass.Text));
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Ошибка базы данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        if (t.Rows.Count == 0)
        {
            MessageBox.Show("Неверный логин или пароль.", "Вход", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtPass.Clear();
            txtPass.Focus();
            return;
        }
        FullName = Convert.ToString(t.Rows[0][0]);
        Role = Convert.ToString(t.Rows[0][1]);
        DialogResult = DialogResult.OK;
    }
}
